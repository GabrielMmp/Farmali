<?php
require_once __DIR__.'/includes.php'; exigir_login();
$id=usuario()['id']; $erro='';
if(empty($_SESSION['csrf_perfil'])) $_SESSION['csrf_perfil']=bin2hex(random_bytes(32));
$s=$conexao->prepare('SELECT * FROM USUARIO WHERE ID_USUARIO=?'); $s->execute([$id]); $u=$s->fetch();
if(isset($_GET['foto'])) { if(!$u['FOTO_PERFIL']) {header('Content-Type: image/svg+xml'); readfile(__DIR__.'/assets/img/avatar-farmali.svg');exit;} header('Content-Type: '.$u['FOTO_MIME']);header('X-Content-Type-Options: nosniff');header('Cache-Control: private, no-store');echo $u['FOTO_PERFIL'];exit; }
if($_SERVER['REQUEST_METHOD']==='POST') {
 if(!hash_equals($_SESSION['csrf_perfil'],$_POST['csrf']??'')) exit('Solicitação inválida.');
 try {
 $nome=trim($_POST['nome']??'');$email=trim($_POST['email']??'');$tel=trim($_POST['telefone']??'');
 if(!$nome||!filter_var($email,FILTER_VALIDATE_EMAIL)||strlen($nome)>150||strlen($email)>190||strlen($tel)>30) throw new RuntimeException('Confira os dados informados.');
 $senha=$u['SENHA']; if(!empty($_POST['nova_senha'])||$email!==$u['EMAIL']) {if(!password_verify($_POST['senha_atual']??'',$senha)) throw new RuntimeException('Informe a senha atual correta.'); if(!empty($_POST['nova_senha'])) {if(strlen($_POST['nova_senha'])<8) throw new RuntimeException('Use pelo menos 8 caracteres.');$senha=password_hash($_POST['nova_senha'],PASSWORD_DEFAULT);}}
 $foto=$u['FOTO_PERFIL'];$mime=$u['FOTO_MIME'];if(isset($_POST['remover'])) {$foto=null;$mime=null;}
 if(isset($_FILES['foto'])&&$_FILES['foto']['error']!==UPLOAD_ERR_NO_FILE){$f=$_FILES['foto'];if($f['error']!==UPLOAD_ERR_OK||$f['size']>2000000) throw new RuntimeException('Foto inválida ou maior que 2 MB.');$info=getimagesize($f['tmp_name']);if(!$info||!in_array($info['mime'],['image/jpeg','image/png','image/webp'],true)) throw new RuntimeException('Use JPG, PNG ou WebP.');$foto=file_get_contents($f['tmp_name']);$mime=$info['mime'];}
 $conexao->beginTransaction();$s=$conexao->prepare('UPDATE USUARIO SET NOME=?,EMAIL=?,TELEFONE=?,SENHA=?,FOTO_PERFIL=?,FOTO_MIME=? WHERE ID_USUARIO=?');$s->execute([$nome,$email,$tel,$senha,$foto,$mime,$id]);$s=$conexao->prepare('UPDATE DADOS_COMPRA SET NOME=?,EMAIL=?,TELEFONE=? WHERE ID_USUARIO=?');$s->execute([$nome,$email,$tel,$id]);$conexao->commit();header('Location: perfil.php?ok=1');exit;
 }catch(Throwable $e){if($conexao->inTransaction())$conexao->rollBack();$erro=$e instanceof PDOException?'Não foi possível salvar. Confira se o e-mail já está em uso.':$e->getMessage();}
}
cabecalho('Editar'); ?>
<div class="config-layout"><nav class="config-nav"><a class="ativo" href="perfil.php">Perfil pessoal</a><a href="enderecos.php">Endereços</a></nav><section class="config-main"><h1>Perfil pessoal</h1><hr><?php if($erro) echo '<p class="aviso aviso-erro">'.h($erro).'</p>';if(isset($_GET['ok'])) echo '<p class="aviso aviso-ok">Perfil atualizado!</p>'; ?>
<form method="post" enctype="multipart/form-data" class="perfil-grid"><input type="hidden" name="csrf" value="<?=h($_SESSION['csrf_perfil'])?>"><div>
<?php foreach(['nome'=>'Nome','email'=>'E-mail','telefone'=>'Telefone'] as $k=>$label):?><div class="campo"><label><?=h($label)?></label><input name="<?=$k?>" value="<?=h($u[strtoupper($k)]??'')?>" <?=$k==='telefone'?'':'required'?>></div><?php endforeach;?>
<p>Perfil: <?=h($u['PERFIL'])?></p><hr><h2>Segurança</h2><div class="campo"><label>Senha atual (para mudar e-mail ou senha)</label><input type="password" name="senha_atual" autocomplete="current-password"></div><div class="campo"><label>Nova senha (opcional)</label><input type="password" name="nova_senha" autocomplete="new-password"></div><button class="btn btn-primario">Salvar perfil</button></div><div class="perfil-foto"><h2>Foto de perfil</h2><img src="perfil.php?foto=1" alt="Foto de perfil"><div class="campo"><label>Alterar foto (até 2 MB)</label><input type="file" name="foto" accept="image/png,image/jpeg,image/webp"></div><label><input type="checkbox" name="remover"> Restaurar foto padrão</label></div></form></section></div><?php rodape(); ?>
