<?php
require_once __DIR__.'/includes.php';
if (usuario()) { header('Location: dashboard.php'); exit; }
$erro='';
if ($_SERVER['REQUEST_METHOD']==='POST') {
    $acao=$_POST['acao']??'login'; $email=trim($_POST['email']??''); $senha=$_POST['senha']??'';
    if ($acao==='cadastro') {
        $nome=trim($_POST['nome']??'');
        if ($nome==='' || !filter_var($email,FILTER_VALIDATE_EMAIL) || strlen($senha)<6) $erro='Preencha nome, e-mail válido e senha com pelo menos 6 caracteres.';
        else { try { $s=$conexao->prepare("INSERT INTO USUARIO(NOME,EMAIL,SENHA,PERFIL) VALUES(?,?,?,'cliente')"); $s->execute([$nome,$email,password_hash($senha,PASSWORD_DEFAULT)]); $_SESSION['usuario']=['id'=>(int)$conexao->lastInsertId(),'nome'=>$nome,'email'=>$email,'perfil'=>'cliente']; header('Location: produtos.php'); exit; } catch(PDOException $e) { $erro='Este e-mail já está cadastrado.'; } }
    } else {
        $s=$conexao->prepare('SELECT ID_USUARIO,NOME,EMAIL,SENHA,PERFIL,ATIVO FROM USUARIO WHERE EMAIL=?'); $s->execute([$email]); $u=$s->fetch();
        if ($u && (int)$u['ATIVO']===1 && password_verify($senha,$u['SENHA'])) { $_SESSION['usuario']=['id'=>(int)$u['ID_USUARIO'],'nome'=>$u['NOME'],'email'=>$u['EMAIL'],'perfil'=>$u['PERFIL']]; header('Location: dashboard.php'); exit; }
        $erro='E-mail ou senha incorretos, ou conta inativa.';
    }
}
?>
<!doctype html><html lang="pt-BR"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Entrar | Farmali</title><link rel="stylesheet" href="assets/css/estilo.css"><style>.pagina-login .caixa-login{width:min(1100px,96vw);max-width:1100px;background:transparent;box-shadow:none}.pagina-login .formularios-acesso{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:24px;text-align:left}.pagina-login .formularios-acesso section{background:white;border:1px solid #dce4e7;border-top:4px solid #198754;border-radius:12px;padding:32px;box-shadow:0 4px 18px #0001}.pagina-login .formularios-acesso section+section{border-top-color:#1976b9}.pagina-login .campo input{width:100%;box-sizing:border-box}.pagina-login .btn{width:100%}@media(max-width:700px){.pagina-login .formularios-acesso{grid-template-columns:1fr}.pagina-login .formularios-acesso section{padding:20px}}</style></head><body><div class="pagina-login"><div class="caixa-login"><img class="login-logo" src="assets/img/logo.png" alt="Farmali"><h1>Bem-vindo à Farmali</h1><p class="sub">Entre ou crie sua conta de cliente</p><?php if($erro):?><div class="aviso aviso-erro"><?=h($erro)?></div><?php endif;?>
<div class="formularios-acesso"><section><h2>Login</h2><form method="post"><input type="hidden" name="acao" value="login"><div class="campo"><label>E-mail</label><input type="email" name="email" required></div><div class="campo"><label>Senha</label><input type="password" name="senha" required></div><button class="btn btn-primario" type="submit">Entrar</button></form></section><section><h2>Cadastrar cliente</h2><form method="post"><input type="hidden" name="acao" value="cadastro"><div class="campo"><label>Nome completo</label><input name="nome" required></div><div class="campo"><label>E-mail</label><input type="email" name="email" required></div><div class="campo"><label>Senha (mínimo 6 caracteres)</label><input type="password" name="senha" minlength="6" required></div><button class="btn btn-primario" type="submit">Criar conta</button></form><p class="dica">Novos cadastros entram como cliente. O administrador pode alterar o perfil depois.</p></section></div></div></div></body></html>
