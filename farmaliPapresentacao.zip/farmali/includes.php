<?php
session_start();
require_once __DIR__ . '/config/conexao.php';
function h($v) { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
function usuario() { global $conexao; if(empty($_SESSION['usuario'])) return null; $s=$conexao->prepare('SELECT ID_USUARIO AS id,NOME AS nome,EMAIL AS email,PERFIL AS perfil,COD_VENDEDOR AS cod_vendedor FROM USUARIO WHERE ID_USUARIO=? AND ATIVO=1'); $s->execute([$_SESSION['usuario']['id']]); return $s->fetch() ?: null; }
function exigir_login() { if (!usuario()) { header('Location: login.php'); exit; } }
function exigir_perfil($perfis) { exigir_login(); if (!in_array(usuario()['perfil'], (array)$perfis, true)) { header('Location: dashboard.php'); exit; } }
function dinheiro($v) { return 'R$ ' . number_format((float)$v, 2, ',', '.'); }
function cabecalho($titulo) {
    $u = usuario();
    echo '<!doctype html><html lang="pt-BR"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>'.h($titulo).' | Farmali</title><link rel="stylesheet" href="/assets/css/estilo.css?v=20261125"></head><body><div class="layout"><aside class="menu"><a class="menu-logo" href="dashboard.php"><img src="assets/img/logo.png" alt="Farmali"></a><nav>';
    if ($u) {
        if ($u['perfil'] !== 'cliente') echo '<a href="dashboard.php">Painel</a>';
        echo '<a href="produtos.php">Produtos</a>';
        if ($u['perfil']==='admin') echo '<a href="crud.php">Cadastro de produtos</a>';
        if ($u['perfil']!=='cliente') echo '<a href="historico.php">Histórico de vendas</a><a href="vendas.php">Venda</a>';
        if ($u['perfil']==='admin') echo '<a href="promover.php">Promover</a>';
        echo '<div class="menu-editar"><a href="perfil.php">&#9881; Editar</a></div>';
    }
    echo '</nav></aside><main class="principal"><header class="barra"><strong>'.h($titulo).'</strong><div class="barra-usuario">';
    if ($u) echo '<a href="perfil.php"><img class="avatar-header" src="perfil.php?foto=1" alt="Perfil"></a>'.h($u['nome']).' <small>('.h($u['perfil']).')</small> <a class="btn btn-claro btn-pequeno" href="logout.php">Sair</a>';
    echo '</div></header><section class="conteudo">';
}
function rodape() { echo '</section></main></div></body></html>'; }
function total_carrinho($pdo, $idUsuario) { $s=$pdo->prepare('SELECT COALESCE(SUM(c.QUANTIDADE*p.PRECO),0) FROM CARRINHO c JOIN PRODUTO p ON p.COD_PRODUTO=c.COD_PRODUTO WHERE c.ID_USUARIO=?'); $s->execute([$idUsuario]); return (float)$s->fetchColumn(); }
