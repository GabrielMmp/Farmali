<?php
require_once __DIR__.'/includes.php'; exigir_perfil(['admin','funcionario']); require_once __DIR__.'/relatorio.php';
if(!isset($_GET['periodo'])) $_GET['periodo']='todos';
$f=filtros_vendas($conexao,usuario());list($w,$args)=$f;
$rows=consulta_vendas($conexao,"SELECT v.*,u.NOME AS VENDEDOR FROM VENDA v LEFT JOIN USUARIO u ON u.ID_USUARIO=v.ID_USUARIO WHERE $w ORDER BY v.DATA_VENDA DESC,v.ID_VENDA DESC",$args);
cabecalho('Histórico de vendas');?><div class="cabecalho"><h1>Histórico de vendas</h1><a class="btn btn-claro" href="dashboard.php">Voltar ao painel</a></div><?php formulario_filtros($conexao,$f); tabela_vendas($conexao,$rows); rodape(); ?>
