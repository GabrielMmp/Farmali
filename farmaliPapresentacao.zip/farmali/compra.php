<?php
require_once __DIR__.'/includes.php'; exigir_perfil(['cliente','funcionario','admin']);
$uid=usuario()['id'];$s=$conexao->prepare('SELECT p.COD_PRODUTO,p.NOME,p.PRECO,p.QUANTIDADE_ESTOQUE,c.QUANTIDADE FROM CARRINHO c JOIN PRODUTO p ON p.COD_PRODUTO=c.COD_PRODUTO WHERE c.ID_USUARIO=?');$s->execute([$uid]);$itens=$s->fetchAll();if(!$itens && !isset($_GET['sucesso'])){header('Location: carrinho.php');exit;}
$subtotal=0;foreach($itens as $i)$subtotal+=(float)$i['PRECO']*(int)$i['QUANTIDADE'];
$s=$conexao->prepare('SELECT NOME AS nome, EMAIL AS email, TELEFONE AS telefone, CEP AS cep, ENDERECO AS endereco, NUMERO AS numero, COMPLEMENTO AS complemento, CIDADE AS cidade, ESTADO AS estado FROM DADOS_COMPRA WHERE ID_USUARIO=?');
$s->execute([$uid]);
$salvos=$s->fetch() ?: null;
$q=$conexao->prepare('SELECT * FROM ENDERECO_USUARIO WHERE ID_USUARIO=? ORDER BY PRINCIPAL DESC,ID_ENDERECO');$q->execute([$uid]);$enderecos=$q->fetchAll();
if($enderecos){$a=$enderecos[0];$q=$conexao->prepare('SELECT TELEFONE FROM USUARIO WHERE ID_USUARIO=?');$q->execute([$uid]);$tel=$q->fetchColumn();$salvos=['nome'=>usuario()['nome'],'email'=>usuario()['email'],'telefone'=>$tel?:($salvos['telefone']??'')];foreach(['cep','endereco','numero','complemento','cidade','estado'] as $k)$salvos[$k]=$a[strtoupper($k)];if(!$salvos['telefone'])$salvos=null;}
$etapa=($_GET['etapa']??'')==='dados' || !$salvos ? 'dados' : 'pagamento';
$erro='';
if(empty($_SESSION['csrf_compra'])) $_SESSION['csrf_compra']=bin2hex(random_bytes(32));
if($_SERVER['REQUEST_METHOD']==='POST' && !hash_equals($_SESSION['csrf_compra'], (string)($_POST['csrf']??''))) {http_response_code(403);exit('Solicitação inválida. Atualize a página.');}
if($_SERVER['REQUEST_METHOD']==='POST' && ($_POST['acao']??'')==='dados'){
 $dados=['nome'=>trim($_POST['nome']??''),'email'=>trim($_POST['email']??''),'telefone'=>trim($_POST['telefone']??''),'cep'=>trim($_POST['cep']??''),'endereco'=>trim($_POST['endereco']??''),'numero'=>trim($_POST['numero']??''),'complemento'=>trim($_POST['complemento']??''),'cidade'=>trim($_POST['cidade']??''),'estado'=>trim($_POST['estado']??'')];
 if($dados['nome']===''||!filter_var($dados['email'],FILTER_VALIDATE_EMAIL)||$dados['telefone']===''||$dados['cep']===''||$dados['endereco']===''||$dados['numero']===''||$dados['cidade']===''||$dados['estado']==='')$erro='Preencha todos os dados obrigatórios e informe um e-mail válido.';
 else {
 $limites=['nome'=>150,'email'=>190,'telefone'=>30,'cep'=>10,'endereco'=>220,'numero'=>20,'complemento'=>100,'cidade'=>100,'estado'=>100];
 foreach($limites as $campo=>$limite) if(strlen($dados[$campo])>$limite) $erro='Um dos campos excede o tamanho permitido.';
 if(!$erro){
 $s=$conexao->prepare('INSERT INTO DADOS_COMPRA (ID_USUARIO,NOME,EMAIL,TELEFONE,CEP,ENDERECO,NUMERO,COMPLEMENTO,CIDADE,ESTADO) VALUES (?,?,?,?,?,?,?,?,?,?) ON DUPLICATE KEY UPDATE NOME=VALUES(NOME),EMAIL=VALUES(EMAIL),TELEFONE=VALUES(TELEFONE),CEP=VALUES(CEP),ENDERECO=VALUES(ENDERECO),NUMERO=VALUES(NUMERO),COMPLEMENTO=VALUES(COMPLEMENTO),CIDADE=VALUES(CIDADE),ESTADO=VALUES(ESTADO)');
 $s->execute(array_merge([$uid],array_values($dados)));
 $q=$conexao->prepare('UPDATE USUARIO SET TELEFONE=? WHERE ID_USUARIO=?');$q->execute([$dados['telefone'],$uid]);
 if(!$enderecos){$q=$conexao->prepare('INSERT INTO ENDERECO_USUARIO(ID_USUARIO,APELIDO,CEP,ENDERECO,NUMERO,COMPLEMENTO,CIDADE,ESTADO,PRINCIPAL) VALUES(?,?,?,?,?,?,?,?,1)');$q->execute([$uid,'Principal',$dados['cep'],$dados['endereco'],$dados['numero'],$dados['complemento'],$dados['cidade'],$dados['estado']]);}else{$q=$conexao->prepare('UPDATE ENDERECO_USUARIO SET CEP=?,ENDERECO=?,NUMERO=?,COMPLEMENTO=?,CIDADE=?,ESTADO=? WHERE ID_USUARIO=? AND ID_ENDERECO=?');$q->execute([$dados['cep'],$dados['endereco'],$dados['numero'],$dados['complemento'],$dados['cidade'],$dados['estado'],$uid,$enderecos[0]['ID_ENDERECO']]);}

 header('Location: compra.php?etapa=pagamento');exit;
 }
}
}
if($_SERVER['REQUEST_METHOD']==='POST' && ($_POST['acao']??'')==='finalizar'){
 $d=$salvos;if($d && $enderecos){$escolhido=null;foreach($enderecos as $a)if($a['ID_ENDERECO']==(int)($_POST['id_endereco']??0))$escolhido=$a;if(!$escolhido)exit('Endereço inválido.');foreach(['cep','endereco','numero','complemento','cidade','estado'] as $k)$d[$k]=$escolhido[strtoupper($k)];}$pagamento=$_POST['pagamento']??'';$entrega=$_POST['entrega']??'';
 if(!$d){header('Location: compra.php?etapa=dados');exit;}
 if(!in_array($pagamento,['pix','credito','debito','dinheiro'],true)||!in_array($entrega,['retirada','entrega'],true))$erro='Selecione uma forma de pagamento e uma opção de recebimento.';
 else {
  $frete=$entrega==='entrega'?10.00:0.00;$total=$subtotal+$frete;
  try{$conexao->beginTransaction();
   foreach($itens as $i){$s=$conexao->prepare("SELECT QUANTIDADE_ESTOQUE,STATUS FROM PRODUTO WHERE COD_PRODUTO=? FOR UPDATE");$s->execute([$i['COD_PRODUTO']]);$p=$s->fetch();if(!$p||$p['STATUS']!=='ATIVO'||(int)$p['QUANTIDADE_ESTOQUE']<(int)$i['QUANTIDADE'])throw new RuntimeException('Estoque insuficiente para '.$i['NOME'].'. Volte ao carrinho e ajuste a quantidade.');}
   $s=$conexao->prepare("INSERT INTO VENDA(ID_USUARIO,NOME_CLIENTE,EMAIL_CLIENTE,TELEFONE,CEP,ENDERECO,NUMERO,COMPLEMENTO,CIDADE,ESTADO,TIPO_ENTREGA,FRETE,FORMA_PAGAMENTO,SUBTOTAL,TOTAL) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
   $s->execute([$uid,$d['nome'],$d['email'],$d['telefone'],$d['cep'],$d['endereco'],$d['numero'],$d['complemento'],$d['cidade'],$d['estado'],$entrega,$frete,$pagamento,$subtotal,$total]);$venda=(int)$conexao->lastInsertId();
   foreach($itens as $i){$s=$conexao->prepare('INSERT INTO ITEM_VENDA(ID_VENDA,COD_PRODUTO,QUANTIDADE,PRECO_UNITARIO) VALUES(?,?,?,?)');$s->execute([$venda,$i['COD_PRODUTO'],$i['QUANTIDADE'],$i['PRECO']]);$s=$conexao->prepare('UPDATE PRODUTO SET QUANTIDADE_ESTOQUE=QUANTIDADE_ESTOQUE-? WHERE COD_PRODUTO=?');$s->execute([$i['QUANTIDADE'],$i['COD_PRODUTO']]);}
   $s=$conexao->prepare('DELETE FROM CARRINHO WHERE ID_USUARIO=?');$s->execute([$uid]);$conexao->commit();unset($_SESSION['dados_compra']);$_SESSION['venda_finalizada']=['id'=>$venda,'total'=>$total];header('Location: compra.php?sucesso=1');exit;
  }catch(Throwable $e){if($conexao->inTransaction())$conexao->rollBack();$erro=$e->getMessage();}
 }
}
if(isset($_GET['sucesso'])&&isset($_SESSION['venda_finalizada'])){$ok=$_SESSION['venda_finalizada'];cabecalho('Compra finalizada');echo '<div class="painel"><h1>Compra registrada!</h1><p>Pedido nº '.(int)$ok['id'].' foi salvo no banco de dados.</p><h2>Total: '.dinheiro($ok['total']).'</h2><a class="btn btn-primario" href="produtos.php">Voltar aos produtos</a></div>';rodape();exit;}
$d=$dados??$salvos??['nome'=>usuario()['nome'],'email'=>usuario()['email'],'telefone'=>'','cep'=>'','endereco'=>'','numero'=>'','complemento'=>'','cidade'=>'','estado'=>''];
cabecalho('Finalizar compra');
?>
<div class="cabecalho"><div><h1><?=($etapa==='dados'?'1. Dados pessoais e endereço':'2. Pagamento e recebimento')?></h1><p class="sub">Subtotal dos produtos: <?=dinheiro($subtotal)?></p></div></div>
<?php if($erro):?><div class="aviso aviso-erro"><?=h($erro)?></div><?php endif;?>
<?php if($etapa==='dados'):?><div class="painel formulario"><form method="post"><input type="hidden" name="csrf" value="<?=h($_SESSION['csrf_compra'])?>"><input type="hidden" name="acao" value="dados"><div class="campo"><label>Nome completo *</label><input name="nome" required value="<?=h($d['nome'])?>"></div><div class="duas-colunas"><div class="campo"><label>E-mail *</label><input type="email" name="email" required value="<?=h($d['email'])?>"></div><div class="campo"><label>Telefone *</label><input name="telefone" required value="<?=h($d['telefone'])?>"></div></div><div class="duas-colunas"><div class="campo"><label>CEP *</label><input name="cep" required value="<?=h($d['cep'])?>"></div><div class="campo"><label>Estado *</label><input name="estado" required value="<?=h($d['estado'])?>"></div></div><div class="campo"><label>Endereço *</label><input name="endereco" required value="<?=h($d['endereco'])?>"></div><div class="duas-colunas"><div class="campo"><label>Número *</label><input name="numero" required value="<?=h($d['numero'])?>"></div><div class="campo"><label>Complemento</label><input name="complemento" value="<?=h($d['complemento'])?>"></div></div><div class="campo"><label>Cidade *</label><input name="cidade" required value="<?=h($d['cidade'])?>"></div><div class="acoes"><a class="btn btn-claro" href="carrinho.php">Voltar ao carrinho</a><button class="btn btn-primario">Continuar</button></div></form></div>
<?php else:?><div class="painel formulario"><form method="post"><input type="hidden" name="csrf" value="<?=h($_SESSION['csrf_compra'])?>"><input type="hidden" name="acao" value="finalizar"><div class="campo"><strong>Dados cadastrados</strong><p><?=h($d['nome'])?> — <?=h($d['telefone'])?></p><p><?=h($d['endereco'])?>, <?=h($d['numero'])?> — <?=h($d['cidade'])?> / <?=h($d['estado'])?> — CEP <?=h($d['cep'])?></p></div><?php if($enderecos):?><div class="campo"><label>Endereço de recebimento</label><select name="id_endereco" required><?php foreach($enderecos as $a):?><option value="<?=h($a['ID_ENDERECO'])?>"><?=h($a['APELIDO'].' — '.$a['ENDERECO'].', '.$a['NUMERO'])?></option><?php endforeach;?></select><a href="enderecos.php">Gerenciar endereços</a></div><?php endif;?><div class="campo"><label>Forma de pagamento</label><select name="pagamento" required><option value="">Selecione</option><option value="pix">PIX</option><option value="credito">Cartão de crédito</option><option value="debito">Cartão de débito</option><option value="dinheiro">Dinheiro</option></select></div><div class="campo"><label>Como deseja receber?</label><select name="entrega" id="entrega" required><option value="">Selecione</option><option value="retirada">Retirar na loja (grátis)</option><option value="entrega">Entrega (frete estimado R$ 10,00)</option></select></div><div class="linha-total"><strong>Subtotal: <?=dinheiro($subtotal)?></strong><p>Frete: calculado conforme a opção de recebimento (R$ 0,00 ou R$ 10,00).</p></div><div class="acoes"><a class="btn btn-claro" href="compra.php?etapa=dados">Alterar dados pessoais e endereço</a><button class="btn btn-primario">Confirmar compra</button></div></form></div><?php endif;?>
<?php rodape(); ?>
