-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: sql209.infinityfree.com
-- Tempo de geração: 24/11/2026 às 14:35
-- Versão do servidor: 11.4.14-MariaDB
-- Versão do PHP: 7.2.22

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `if0_43525538_db_farmali`
--

-- --------------------------------------------------------

--
-- Estrutura para tabela `CARRINHO`
--

CREATE TABLE `CARRINHO` (
  `ID_CARRINHO` int(11) NOT NULL,
  `ID_USUARIO` int(11) NOT NULL,
  `COD_PRODUTO` int(11) NOT NULL,
  `QUANTIDADE` int(11) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `CATEGORIA`
--

CREATE TABLE `CATEGORIA` (
  `COD_CATEGORIA` int(11) NOT NULL,
  `NOME` varchar(100) NOT NULL,
  `DESCRICAO` text DEFAULT NULL,
  `STATUS` enum('ATIVO','INATIVO') DEFAULT 'ATIVO',
  `DATA_CADASTRO` timestamp NULL DEFAULT current_timestamp()
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Despejando dados para a tabela `CATEGORIA`
--

INSERT INTO `CATEGORIA` (`COD_CATEGORIA`, `NOME`, `DESCRICAO`, `STATUS`, `DATA_CADASTRO`) VALUES
(1, 'Medicamentos', 'Produtos farmacêuticos', 'ATIVO', '2026-11-24 18:02:42'),
(2, 'Higiene', 'Produtos de higiene pessoal', 'ATIVO', '2026-11-24 18:02:42'),
(3, 'Beleza', 'Cosméticos e cuidados pessoais', 'ATIVO', '2026-11-24 18:02:42'),
(4, 'Vitaminas', 'Vitaminas e suplementos', 'ATIVO', '2026-11-24 18:02:42'),
(5, 'Utensílios', 'Acessórios de saúde', 'ATIVO', '2026-11-24 18:02:42'),
(6, 'Medicamentos', 'Produtos farmacêuticos', 'ATIVO', '2026-11-24 18:03:43'),
(7, 'Higiene', 'Produtos de higiene pessoal', 'ATIVO', '2026-11-24 18:03:43'),
(8, 'Beleza', 'Cosméticos e cuidados pessoais', 'ATIVO', '2026-11-24 18:03:43'),
(9, 'Vitaminas', 'Vitaminas e suplementos', 'ATIVO', '2026-11-24 18:03:43'),
(10, 'Utensílios', 'Acessórios de saúde', 'ATIVO', '2026-11-24 18:03:43'),
(11, 'Medicamentos', 'Produtos farmacêuticos', 'ATIVO', '2026-11-24 18:11:34'),
(12, 'Higiene', 'Produtos de higiene pessoal', 'ATIVO', '2026-11-24 18:11:34'),
(13, 'Beleza', 'Cosméticos e cuidados pessoais', 'ATIVO', '2026-11-24 18:11:34'),
(14, 'Vitaminas', 'Vitaminas e suplementos', 'ATIVO', '2026-11-24 18:11:34'),
(15, 'Utensílios', 'Acessórios de saúde', 'ATIVO', '2026-11-24 18:11:34'),
(16, 'Medicamentos', 'Produtos farmacêuticos', 'ATIVO', '2026-11-24 18:18:43'),
(17, 'Higiene', 'Produtos de higiene pessoal', 'ATIVO', '2026-11-24 18:18:43'),
(18, 'Beleza', 'Cosméticos e cuidados pessoais', 'ATIVO', '2026-11-24 18:18:43'),
(19, 'Vitaminas', 'Vitaminas e suplementos', 'ATIVO', '2026-11-24 18:18:43'),
(20, 'Utensílios', 'Acessórios de saúde', 'ATIVO', '2026-11-24 18:18:43'),
(21, 'Medicamentos', 'Produtos farmacêuticos', 'ATIVO', '2026-11-24 18:19:50'),
(22, 'Higiene', 'Produtos de higiene pessoal', 'ATIVO', '2026-11-24 18:19:50'),
(23, 'Beleza', 'Cosméticos e cuidados pessoais', 'ATIVO', '2026-11-24 18:19:50'),
(24, 'Vitaminas', 'Vitaminas e suplementos', 'ATIVO', '2026-11-24 18:19:50'),
(25, 'Utensílios', 'Acessórios de saúde', 'ATIVO', '2026-11-24 18:19:50');

-- --------------------------------------------------------

--
-- Estrutura para tabela `CLIENTE`
--

CREATE TABLE `CLIENTE` (
  `COD_CLIENTE` int(11) NOT NULL,
  `NOME` varchar(250) NOT NULL,
  `DATA_NASCIMENTO` date DEFAULT NULL,
  `EMAIL` varchar(255) DEFAULT NULL,
  `TELEFONE` varchar(20) DEFAULT NULL,
  `DATA_CADASTRO` timestamp NULL DEFAULT current_timestamp(),
  `COD_LOGRADOURO_FK` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `FORNECEDOR`
--

CREATE TABLE `FORNECEDOR` (
  `COD_FORNECEDOR` int(11) NOT NULL,
  `NOME` varchar(200) NOT NULL,
  `CNPJ` varchar(20) DEFAULT NULL,
  `EMAIL` varchar(150) DEFAULT NULL,
  `TELEFONE` varchar(20) DEFAULT NULL,
  `CONTATO` varchar(100) DEFAULT NULL,
  `STATUS` enum('ATIVO','INATIVO') DEFAULT 'ATIVO',
  `DATA_CADASTRO` timestamp NULL DEFAULT current_timestamp()
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `ITEM_NOTA_FISCAL`
--

CREATE TABLE `ITEM_NOTA_FISCAL` (
  `ID_ITEM` int(11) NOT NULL,
  `QTD_VENDIDA` int(11) NOT NULL,
  `PRECO_UNITARIO` decimal(15,2) NOT NULL,
  `SUBTOTAL` decimal(15,2) GENERATED ALWAYS AS (`QTD_VENDIDA` * `PRECO_UNITARIO`) STORED,
  `NUMERO_NF_FK` int(11) NOT NULL,
  `COD_PRODUTO_FK` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `ITEM_PEDIDO_COMPRA`
--

CREATE TABLE `ITEM_PEDIDO_COMPRA` (
  `COD_PEDIDO_FK` int(11) NOT NULL,
  `COD_PRODUTO_FK` int(11) NOT NULL,
  `QTD` int(11) NOT NULL,
  `PRECO_COMPRA` decimal(10,2) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `ITEM_VENDA`
--

CREATE TABLE `ITEM_VENDA` (
  `ID_ITEM` int(11) NOT NULL,
  `ID_VENDA` int(11) NOT NULL,
  `COD_PRODUTO` int(11) NOT NULL,
  `QUANTIDADE` int(11) NOT NULL,
  `PRECO_UNITARIO` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Despejando dados para a tabela `ITEM_VENDA`
--

INSERT INTO `ITEM_VENDA` (`ID_ITEM`, `ID_VENDA`, `COD_PRODUTO`, `QUANTIDADE`, `PRECO_UNITARIO`) VALUES
(1, 1, 7, 11, '6.90'),
(2, 2, 11, 3, '8.50'),
(3, 2, 22, 4, '6.90');

-- --------------------------------------------------------

--
-- Estrutura para tabela `LOGRADOURO`
--

CREATE TABLE `LOGRADOURO` (
  `COD_LOGRADOURO` int(11) NOT NULL,
  `TIPO_LOGRADOURO` varchar(50) NOT NULL,
  `NOME` varchar(250) NOT NULL,
  `NUMERO` varchar(10) DEFAULT NULL,
  `COMPLEMENTO` varchar(100) DEFAULT NULL,
  `CIDADE` varchar(100) NOT NULL,
  `ESTADO` varchar(100) NOT NULL,
  `CEP` varchar(10) NOT NULL,
  `PONTO_REFERENCIA` varchar(255) DEFAULT NULL,
  `DATA_INCLUSAO` timestamp NULL DEFAULT current_timestamp(),
  `STATUS` enum('ATIVO','INATIVO') DEFAULT 'ATIVO'
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `NOTA_FISCAL`
--

CREATE TABLE `NOTA_FISCAL` (
  `NUMERO_NF` int(11) NOT NULL,
  `DATA_EMISSAO` date NOT NULL,
  `DATA_VENCIMENTO` date DEFAULT NULL,
  `VALOR_TOTAL` decimal(15,2) NOT NULL,
  `STATUS` enum('PAGO','PENDENTE','CANCELADO') DEFAULT 'PENDENTE',
  `FORMA_PAGAMENTO` varchar(50) DEFAULT NULL,
  `OBSERVACOES` text DEFAULT NULL,
  `COD_CLIENTE_FK` int(11) DEFAULT NULL,
  `DATA_INCLUSAO` timestamp NULL DEFAULT current_timestamp()
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `PEDIDO_COMPRA`
--

CREATE TABLE `PEDIDO_COMPRA` (
  `COD_PEDIDO` int(11) NOT NULL,
  `DATA_PEDIDO` date NOT NULL,
  `STATUS` enum('ABERTO','FINALIZADO','CANCELADO') DEFAULT 'ABERTO',
  `COD_FORNECEDOR_FK` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `PRODUTO`
--

CREATE TABLE `PRODUTO` (
  `COD_PRODUTO` int(11) NOT NULL,
  `NOME` varchar(250) NOT NULL,
  `DESCRICAO` text DEFAULT NULL,
  `PRECO` decimal(10,2) NOT NULL,
  `QUANTIDADE_ESTOQUE` int(11) NOT NULL DEFAULT 0,
  `DATA_VALIDADE` date DEFAULT NULL,
  `IMAGEM_URL` varchar(500) DEFAULT NULL,
  `COD_CATEGORIA_FK` int(11) DEFAULT NULL,
  `DATA_INCLUSAO` timestamp NULL DEFAULT current_timestamp(),
  `STATUS` enum('ATIVO','INATIVO') DEFAULT 'ATIVO'
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Despejando dados para a tabela `PRODUTO`
--

INSERT INTO `PRODUTO` (`COD_PRODUTO`, `NOME`, `DESCRICAO`, `PRECO`, `QUANTIDADE_ESTOQUE`, `DATA_VALIDADE`, `IMAGEM_URL`, `COD_CATEGORIA_FK`, `DATA_INCLUSAO`, `STATUS`) VALUES
(1, 'Paracetamol 500 mg', 'Produto demonstrativo', '8.50', 40, NULL, NULL, 1, '2026-11-24 18:02:42', 'ATIVO'),
(2, 'Álcool 70%', 'Produto demonstrativo', '6.90', 25, NULL, NULL, 2, '2026-11-24 18:02:42', 'INATIVO'),
(3, 'Protetor solar FPS 50', 'Produto demonstrativo', '39.90', 15, NULL, NULL, 3, '2026-11-24 18:02:42', 'ATIVO'),
(4, 'Vitamina C', 'Produto demonstrativo', '19.90', 20, NULL, NULL, 4, '2026-11-24 18:02:42', 'ATIVO'),
(5, 'Termômetro digital', 'Produto demonstrativo', '24.90', 10, NULL, NULL, 5, '2026-11-24 18:02:42', 'ATIVO'),
(6, 'Paracetamol 500 mg', 'Produto demonstrativo', '8.50', 40, NULL, NULL, 1, '2026-11-24 18:03:43', 'ATIVO'),
(7, 'Álcool 70%', 'Produto demonstrativo', '6.90', 20, NULL, NULL, 5, '2026-11-24 18:03:43', 'ATIVO'),
(8, 'Protetor solar FPS 50', 'Produto demonstrativo', '39.90', 15, NULL, NULL, 3, '2026-11-24 18:03:43', 'ATIVO'),
(9, 'Vitamina C', 'Produto demonstrativo', '19.90', 20, NULL, NULL, 4, '2026-11-24 18:03:43', 'ATIVO'),
(10, 'Termômetro digital', 'Produto demonstrativo', '24.90', 10, NULL, NULL, 5, '2026-11-24 18:03:43', 'ATIVO'),
(11, 'Paracetamol 500 mg', 'Produto demonstrativo', '8.50', 37, NULL, NULL, 1, '2026-11-24 18:11:34', 'ATIVO'),
(12, 'Álcool 70%', 'Produto demonstrativo', '6.90', 25, NULL, NULL, 2, '2026-11-24 18:11:34', 'ATIVO'),
(13, 'Protetor solar FPS 50', 'Produto demonstrativo', '39.90', 15, NULL, NULL, 3, '2026-11-24 18:11:34', 'ATIVO'),
(14, 'Vitamina C', 'Produto demonstrativo', '19.90', 20, NULL, NULL, 4, '2026-11-24 18:11:34', 'ATIVO'),
(15, 'Termômetro digital', 'Produto demonstrativo', '24.90', 10, NULL, NULL, 5, '2026-11-24 18:11:34', 'ATIVO'),
(16, 'Paracetamol 500 mg', 'Produto demonstrativo', '8.50', 40, NULL, NULL, 1, '2026-11-24 18:18:43', 'ATIVO'),
(17, 'Álcool 70%', 'Produto demonstrativo', '6.90', 25, NULL, NULL, 2, '2026-11-24 18:18:43', 'ATIVO'),
(18, 'Protetor solar FPS 50', 'Produto demonstrativo', '39.90', 15, NULL, NULL, 3, '2026-11-24 18:18:43', 'ATIVO'),
(19, 'Vitamina C', 'Produto demonstrativo', '19.90', 20, NULL, NULL, 4, '2026-11-24 18:18:43', 'ATIVO'),
(20, 'Termômetro digital', 'Produto demonstrativo', '24.90', 10, NULL, NULL, 5, '2026-11-24 18:18:43', 'ATIVO'),
(21, 'Paracetamol 500 mg', 'Produto demonstrativo', '8.50', 40, NULL, NULL, 1, '2026-11-24 18:19:50', 'ATIVO'),
(22, 'Álcool 70%', 'Produto demonstrativo', '6.90', 21, NULL, NULL, 2, '2026-11-24 18:19:50', 'ATIVO'),
(23, 'Protetor solar FPS 50', 'Produto demonstrativo', '39.90', 15, NULL, NULL, 3, '2026-11-24 18:19:50', 'ATIVO'),
(24, 'Vitamina C', 'Produto demonstrativo', '19.90', 20, NULL, NULL, 4, '2026-11-24 18:19:50', 'ATIVO'),
(25, 'Termômetro digital', 'Produto demonstrativo', '24.90', 10, NULL, NULL, 5, '2026-11-24 18:19:50', 'ATIVO');

-- --------------------------------------------------------

--
-- Estrutura para tabela `USUARIO`
--

CREATE TABLE `USUARIO` (
  `ID_USUARIO` int(11) NOT NULL,
  `NOME` varchar(150) NOT NULL,
  `EMAIL` varchar(190) NOT NULL,
  `SENHA` varchar(255) NOT NULL,
  `PERFIL` enum('admin','funcionario','cliente') NOT NULL DEFAULT 'cliente',
  `ATIVO` tinyint(1) NOT NULL DEFAULT 1,
  `DATA_CADASTRO` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Despejando dados para a tabela `USUARIO`
--

INSERT INTO `USUARIO` (`ID_USUARIO`, `NOME`, `EMAIL`, `SENHA`, `PERFIL`, `ATIVO`, `DATA_CADASTRO`) VALUES
(1, 'João Costa', 'jc1122@gmail.com', 'jc1122', 'admin', 1, '2026-11-24 18:22:33'),
(2, 'João Henrique Leite Costa', 'farmali1122@gmail.com', '$2y$12$/Z1MS7wzrQ0z7pivrw2ufOeOdXlQ5bc6jyBJrRaTYidphgPgojrga', 'admin', 1, '2026-11-24 18:47:45'),
(4, 'Ligia Santos', 'li12@gmail.com', '$2y$12$lURZSURS9nUzXLI8GklcA.JP9SDhTN3f.JT8qGe20dLj1Wdjz1jxK', 'admin', 1, '2026-11-24 19:08:34'),
(5, 'Silvio Siqueira', 'silvio12@gmail.com', '$2y$12$.B1hUXJujHzJnnLHzyYEeen587WtGA7ovIdTrr.cNvgFFkCPj4S2q', 'cliente', 1, '2026-11-24 19:14:10');

-- --------------------------------------------------------

--
-- Estrutura para tabela `VENDA`
--

CREATE TABLE `VENDA` (
  `ID_VENDA` int(11) NOT NULL,
  `ID_USUARIO` int(11) DEFAULT NULL,
  `NOME_CLIENTE` varchar(150) NOT NULL,
  `EMAIL_CLIENTE` varchar(190) DEFAULT NULL,
  `TELEFONE` varchar(30) DEFAULT NULL,
  `CEP` varchar(10) DEFAULT NULL,
  `ENDERECO` varchar(220) DEFAULT NULL,
  `NUMERO` varchar(20) DEFAULT NULL,
  `COMPLEMENTO` varchar(100) DEFAULT NULL,
  `CIDADE` varchar(100) DEFAULT NULL,
  `ESTADO` varchar(100) DEFAULT NULL,
  `TIPO_ENTREGA` enum('retirada','entrega') NOT NULL,
  `FRETE` decimal(10,2) NOT NULL DEFAULT 0.00,
  `FORMA_PAGAMENTO` enum('pix','credito','debito','dinheiro') NOT NULL,
  `SUBTOTAL` decimal(10,2) NOT NULL,
  `TOTAL` decimal(10,2) NOT NULL,
  `STATUS` enum('PENDENTE','FINALIZADA','CANCELADA') NOT NULL DEFAULT 'FINALIZADA',
  `DATA_VENDA` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Despejando dados para a tabela `VENDA`
--

INSERT INTO `VENDA` (`ID_VENDA`, `ID_USUARIO`, `NOME_CLIENTE`, `EMAIL_CLIENTE`, `TELEFONE`, `CEP`, `ENDERECO`, `NUMERO`, `COMPLEMENTO`, `CIDADE`, `ESTADO`, `TIPO_ENTREGA`, `FRETE`, `FORMA_PAGAMENTO`, `SUBTOTAL`, `TOTAL`, `STATUS`, `DATA_VENDA`) VALUES
(1, 2, 'João Henrique Leite Costa', 'farmali1122@gmail.com', '11194619651', '04872111', 'av ahfaga', '123', 'casa 1', 'poa', 'sp', 'retirada', '0.00', 'pix', '75.90', '75.90', 'FINALIZADA', '2026-11-24 19:07:30'),
(2, 4, 'Ligia Santos', 'li12@gmail.com', '11194619651', '04872111', 'av ahfaga', '123', 'casa 1', 'poa', 'sp', 'retirada', '0.00', 'pix', '53.10', '53.10', 'FINALIZADA', '2026-11-24 19:10:07');

--
-- Índices de tabelas apagadas
--

--
-- Índices de tabela `CARRINHO`
--
ALTER TABLE `CARRINHO`
  ADD PRIMARY KEY (`ID_CARRINHO`),
  ADD UNIQUE KEY `ID_USUARIO` (`ID_USUARIO`,`COD_PRODUTO`),
  ADD KEY `COD_PRODUTO` (`COD_PRODUTO`);

--
-- Índices de tabela `CATEGORIA`
--
ALTER TABLE `CATEGORIA`
  ADD PRIMARY KEY (`COD_CATEGORIA`);

--
-- Índices de tabela `CLIENTE`
--
ALTER TABLE `CLIENTE`
  ADD PRIMARY KEY (`COD_CLIENTE`),
  ADD UNIQUE KEY `EMAIL` (`EMAIL`),
  ADD KEY `COD_LOGRADOURO_FK` (`COD_LOGRADOURO_FK`);

--
-- Índices de tabela `FORNECEDOR`
--
ALTER TABLE `FORNECEDOR`
  ADD PRIMARY KEY (`COD_FORNECEDOR`),
  ADD UNIQUE KEY `CNPJ` (`CNPJ`);

--
-- Índices de tabela `ITEM_NOTA_FISCAL`
--
ALTER TABLE `ITEM_NOTA_FISCAL`
  ADD PRIMARY KEY (`ID_ITEM`),
  ADD KEY `NUMERO_NF_FK` (`NUMERO_NF_FK`),
  ADD KEY `COD_PRODUTO_FK` (`COD_PRODUTO_FK`);

--
-- Índices de tabela `ITEM_PEDIDO_COMPRA`
--
ALTER TABLE `ITEM_PEDIDO_COMPRA`
  ADD PRIMARY KEY (`COD_PEDIDO_FK`,`COD_PRODUTO_FK`),
  ADD KEY `COD_PRODUTO_FK` (`COD_PRODUTO_FK`);

--
-- Índices de tabela `ITEM_VENDA`
--
ALTER TABLE `ITEM_VENDA`
  ADD PRIMARY KEY (`ID_ITEM`),
  ADD KEY `ID_VENDA` (`ID_VENDA`),
  ADD KEY `COD_PRODUTO` (`COD_PRODUTO`);

--
-- Índices de tabela `LOGRADOURO`
--
ALTER TABLE `LOGRADOURO`
  ADD PRIMARY KEY (`COD_LOGRADOURO`);

--
-- Índices de tabela `NOTA_FISCAL`
--
ALTER TABLE `NOTA_FISCAL`
  ADD PRIMARY KEY (`NUMERO_NF`),
  ADD KEY `COD_CLIENTE_FK` (`COD_CLIENTE_FK`);

--
-- Índices de tabela `PEDIDO_COMPRA`
--
ALTER TABLE `PEDIDO_COMPRA`
  ADD PRIMARY KEY (`COD_PEDIDO`),
  ADD KEY `COD_FORNECEDOR_FK` (`COD_FORNECEDOR_FK`);

--
-- Índices de tabela `PRODUTO`
--
ALTER TABLE `PRODUTO`
  ADD PRIMARY KEY (`COD_PRODUTO`),
  ADD KEY `COD_CATEGORIA_FK` (`COD_CATEGORIA_FK`);

--
-- Índices de tabela `USUARIO`
--
ALTER TABLE `USUARIO`
  ADD PRIMARY KEY (`ID_USUARIO`),
  ADD UNIQUE KEY `EMAIL` (`EMAIL`);

--
-- Índices de tabela `VENDA`
--
ALTER TABLE `VENDA`
  ADD PRIMARY KEY (`ID_VENDA`),
  ADD KEY `ID_USUARIO` (`ID_USUARIO`);

--
-- AUTO_INCREMENT de tabelas apagadas
--

--
-- AUTO_INCREMENT de tabela `CARRINHO`
--
ALTER TABLE `CARRINHO`
  MODIFY `ID_CARRINHO` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT de tabela `CATEGORIA`
--
ALTER TABLE `CATEGORIA`
  MODIFY `COD_CATEGORIA` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT de tabela `CLIENTE`
--
ALTER TABLE `CLIENTE`
  MODIFY `COD_CLIENTE` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `FORNECEDOR`
--
ALTER TABLE `FORNECEDOR`
  MODIFY `COD_FORNECEDOR` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `ITEM_NOTA_FISCAL`
--
ALTER TABLE `ITEM_NOTA_FISCAL`
  MODIFY `ID_ITEM` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `ITEM_VENDA`
--
ALTER TABLE `ITEM_VENDA`
  MODIFY `ID_ITEM` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de tabela `LOGRADOURO`
--
ALTER TABLE `LOGRADOURO`
  MODIFY `COD_LOGRADOURO` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `NOTA_FISCAL`
--
ALTER TABLE `NOTA_FISCAL`
  MODIFY `NUMERO_NF` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `PEDIDO_COMPRA`
--
ALTER TABLE `PEDIDO_COMPRA`
  MODIFY `COD_PEDIDO` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `PRODUTO`
--
ALTER TABLE `PRODUTO`
  MODIFY `COD_PRODUTO` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT de tabela `USUARIO`
--
ALTER TABLE `USUARIO`
  MODIFY `ID_USUARIO` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de tabela `VENDA`
--
ALTER TABLE `VENDA`
  MODIFY `ID_VENDA` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Restrições para dumps de tabelas
--

--
-- Restrições para tabelas `CARRINHO`
--
ALTER TABLE `CARRINHO`
  ADD CONSTRAINT `CARRINHO_ibfk_1` FOREIGN KEY (`ID_USUARIO`) REFERENCES `USUARIO` (`ID_USUARIO`) ON DELETE CASCADE,
  ADD CONSTRAINT `CARRINHO_ibfk_2` FOREIGN KEY (`COD_PRODUTO`) REFERENCES `PRODUTO` (`COD_PRODUTO`) ON DELETE CASCADE;

--
-- Restrições para tabelas `ITEM_VENDA`
--
ALTER TABLE `ITEM_VENDA`
  ADD CONSTRAINT `ITEM_VENDA_ibfk_1` FOREIGN KEY (`ID_VENDA`) REFERENCES `VENDA` (`ID_VENDA`) ON DELETE CASCADE,
  ADD CONSTRAINT `ITEM_VENDA_ibfk_2` FOREIGN KEY (`COD_PRODUTO`) REFERENCES `PRODUTO` (`COD_PRODUTO`);

--
-- Restrições para tabelas `VENDA`
--
ALTER TABLE `VENDA`
  ADD CONSTRAINT `VENDA_ibfk_1` FOREIGN KEY (`ID_USUARIO`) REFERENCES `USUARIO` (`ID_USUARIO`) ON DELETE SET NULL;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;


-- Atualizacao Farmali: PDV e cadastro de produtos
ALTER TABLE `USUARIO`
  ADD COLUMN `COD_VENDEDOR` INT DEFAULT NULL,
  ADD UNIQUE KEY `UK_VENDEDOR` (`COD_VENDEDOR`);

ALTER TABLE `PRODUTO`
  ADD COLUMN `CUSTO` DECIMAL(10,2) NOT NULL DEFAULT 0,
  ADD COLUMN `MARGEM` DECIMAL(10,2) NOT NULL DEFAULT 0,
  ADD COLUMN `COD_FORNECEDOR_FK` INT DEFAULT NULL,
  ADD KEY `IDX_PRODUTO_FORNECEDOR` (`COD_FORNECEDOR_FK`);

ALTER TABLE `FORNECEDOR` ENGINE=InnoDB;
ALTER TABLE `PRODUTO`
  ADD CONSTRAINT `FK_PRODUTO_FORNECEDOR` FOREIGN KEY (`COD_FORNECEDOR_FK`) REFERENCES `FORNECEDOR` (`COD_FORNECEDOR`) ON DELETE SET NULL;

ALTER TABLE `VENDA`
  ADD COLUMN `COD_VENDEDOR` INT DEFAULT NULL,
  ADD COLUMN `DESCONTO` DECIMAL(10,2) NOT NULL DEFAULT 0,
  ADD COLUMN `TIPO_VENDA` ENUM('online','presencial') NOT NULL DEFAULT 'online';

-- Dados de pre-pagamento por conta
CREATE TABLE IF NOT EXISTS DADOS_COMPRA (
 ID_USUARIO INT NOT NULL PRIMARY KEY,
 NOME VARCHAR(150) NOT NULL, EMAIL VARCHAR(190) NOT NULL,
 TELEFONE VARCHAR(30) NOT NULL, CEP VARCHAR(10) NOT NULL,
 ENDERECO VARCHAR(220) NOT NULL, NUMERO VARCHAR(20) NOT NULL,
 COMPLEMENTO VARCHAR(100) NOT NULL DEFAULT '',
 CIDADE VARCHAR(100) NOT NULL, ESTADO VARCHAR(100) NOT NULL,
 ATUALIZADO_EM TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
 FOREIGN KEY (ID_USUARIO) REFERENCES USUARIO(ID_USUARIO) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
