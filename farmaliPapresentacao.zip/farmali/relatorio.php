<?php
// Funções compartilhadas pelo painel e histórico.
function filtros_vendas($pdo,$u){
 $periodo=$_GET['periodo']??'mes'; $produto=max(0,(int)($_GET['produto']??0));
 $hoje=new DateTimeImmutable('today',new DateTimeZone('America/Sao_Paulo'));
 $inicio=$hoje->modify('first day of this month'); $fim=$hoje;
 if($periodo==='dia') $inicio=$hoje;
 elseif($periodo==='semana') $inicio=$hoje->modify('monday this week');
 elseif($periodo==='todos') $inicio=new DateTimeImmutable('2000-01-01');
 elseif($periodo==='personalizado') { foreach(['inicio','fim'] as $k){$v=$_GET[$k]??''; $d=DateTimeImmutable::createFromFormat('!Y-m-d',$v); if($d && $d->format('Y-m-d')===$v) $$k=$d;} }
 $a=$inicio->format('Y-m-d');$b=$fim->format('Y-m-d');
 $where='v.DATA_VENDA >= ? AND v.DATA_VENDA < ?';$args=[$a,$fim->modify('+1 day')->format('Y-m-d')];
 if($u['perfil']==='funcionario'){$where.=" AND v.ID_USUARIO=? AND v.TIPO_VENDA='presencial'";$args[]=$u['id'];}
 if($produto){$where.=' AND EXISTS (SELECT 1 FROM ITEM_VENDA f WHERE f.ID_VENDA=v.ID_VENDA AND f.COD_PRODUTO=?)';$args[]=$produto;}
 return [$where,$args,$produto,$periodo,$a,$b];
}
function consulta_vendas($pdo,$sql,$args){$s=$pdo->prepare($sql);$s->execute($args);return $s->fetchAll();}
function formulario_filtros($pdo,$f){list($w,$args,$produto,$periodo,$a,$b)=$f;$ps=$pdo->query('SELECT COD_PRODUTO,NOME FROM PRODUTO ORDER BY NOME')->fetchAll(); ?>
<form method="get" class="painel" style="display:flex;gap:12px;flex-wrap:wrap;align-items:end"><div class="campo"><label>Período</label><select name="periodo"><?php foreach(['dia'=>'Hoje','semana'=>'Esta semana','mes'=>'Este mês','todos'=>'Todo o histórico','personalizado'=>'Personalizado'] as $k=>$v):?><option value="<?=$k?>" <?=$periodo===$k?'selected':''?>><?=h($v)?></option><?php endforeach;?></select></div><div class="campo"><label>De (personalizado)</label><input type="date" name="inicio" value="<?=h($a)?>"></div><div class="campo"><label>Até (personalizado)</label><input type="date" name="fim" value="<?=h($b)?>"></div><div class="campo"><label>Produto</label><select name="produto"><option value="0">Todos</option><?php foreach($ps as $p):?><option value="<?=$p['COD_PRODUTO']?>" <?=$produto==(int)$p['COD_PRODUTO']?'selected':''?>><?=h($p['NOME'])?> (#<?=$p['COD_PRODUTO']?>)</option><?php endforeach;?></select></div><button class="btn btn-primario">Filtrar</button></form><?php }
function tabela_vendas($pdo,$rows){?><div class="tabela-area"><table><thead><tr><th>Venda / Data</th><th>Vendedor</th><th>Cliente</th><th>Produtos / Preço unitário</th><th>Subtotal</th><th>Desconto</th><th>Frete</th><th>Total</th><th>Pagamento / Status</th></tr></thead><tbody><?php foreach($rows as $v):?><tr><td>#<?=$v['ID_VENDA']?><br><?=h($v['DATA_VENDA'])?></td><td><?= $v['TIPO_VENDA']==='online'?'Online':h(($v['COD_VENDEDOR']??'—').' - '.($v['VENDEDOR']??'—'))?></td><td><?=h($v['NOME_CLIENTE'])?></td><td><?php foreach(consulta_vendas($pdo,'SELECT i.*,p.NOME FROM ITEM_VENDA i JOIN PRODUTO p ON p.COD_PRODUTO=i.COD_PRODUTO WHERE i.ID_VENDA=?',[$v['ID_VENDA']]) as $i):?><div><?=h($i['NOME'])?> × <?=$i['QUANTIDADE']?> — <?=dinheiro($i['PRECO_UNITARIO'])?></div><?php endforeach;?></td><td><?=dinheiro($v['SUBTOTAL'])?></td><td><?=dinheiro($v['DESCONTO'])?></td><td><?=dinheiro($v['FRETE'])?></td><td><?=dinheiro($v['TOTAL'])?></td><td><?=h($v['FORMA_PAGAMENTO'])?><br><?=h($v['STATUS'])?></td></tr><?php endforeach;?><?php if(!$rows):?><tr><td colspan="9">Nenhuma venda encontrada.</td></tr><?php endif;?></tbody></table></div><?php }
