<?php
/* produto_excluir.php - Exclui um produto (DELETE). Só aceita POST. */
require_once __DIR__ . '/includes/funcoes.php';
exigir_login();
csrf_validar();

$id = (int) ($_POST['id'] ?? 0);

if ($id > 0) {
    $stmt = conectar()->prepare('DELETE FROM produtos WHERE id = :id');
    $stmt->execute([':id' => $id]);
    aviso($stmt->rowCount() ? 'Produto excluído.' : 'Produto não encontrado.', $stmt->rowCount() ? 'ok' : 'erro');
}
redirecionar('produtos.php');
