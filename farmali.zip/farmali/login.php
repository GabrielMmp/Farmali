<?php
/* login.php - Tela de entrada: confere e-mail e senha no banco de dados */
require_once __DIR__ . '/includes/funcoes.php';

// Quem já está logado vai direto ao painel
if (usuario_logado()) {
    redirecionar('dashboard.php');
}

$erro  = '';
$email = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_validar();
    $email = trim($_POST['email'] ?? '');
    $senha = $_POST['senha'] ?? '';

    // Busca o usuário pelo e-mail (consulta preparada = segura)
    $stmt = conectar()->prepare('SELECT id, nome, email, senha_hash, perfil, ativo FROM usuarios WHERE email = :email');
    $stmt->execute([':email' => $email]);
    $u = $stmt->fetch();

    // Compara a senha digitada com o hash guardado
    if ($u && $u['ativo'] && password_verify($senha, $u['senha_hash'])) {
        session_regenerate_id(true); // novo ID de sessão após o login
        $_SESSION['usuario'] = [
            'id'     => (int) $u['id'],
            'nome'   => $u['nome'],
            'email'  => $u['email'],
            'perfil' => $u['perfil'],
        ];
        redirecionar('dashboard.php');
    }
    $erro = 'E-mail ou senha incorretos (ou usuário inativo).';
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Entrar | Farmali</title>
    <link rel="icon" href="assets/img/logo.png">
    <link rel="stylesheet" href="assets/css/estilo.css">
</head>
<body class="pagina-login">
    <main class="caixa-login">
        <img class="login-logo" src="assets/img/logo.png" alt="Farmali Farmácia">
        <h1>Acesse sua conta</h1>
        <p class="sub">Entre no painel de gestão da farmácia.</p>

        <?php if ($erro): ?><div class="aviso aviso-erro"><?= h($erro) ?></div><?php endif; ?>

        <form method="post" autocomplete="off">
            <?= csrf_campo() ?>
            <div class="campo">
                <label for="email">E-mail</label>
                <input id="email" name="email" type="email" value="<?= h($email) ?>" required autofocus>
            </div>
            <div class="campo">
                <label for="senha">Senha</label>
                <input id="senha" name="senha" type="password" required>
            </div>
            <button class="btn btn-primario" type="submit">Entrar no sistema</button>
        </form>

        <div class="dica">
            <strong>Acesso de demonstração</strong><br>
            admin@farmali.com / 123456
        </div>
    </main>
</body>
</html>
