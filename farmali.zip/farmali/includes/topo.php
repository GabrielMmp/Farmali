<?php
/*
 * topo.php
 * Início do layout (menu lateral + barra superior).
 * Cada página define antes: $titulo (texto) e $pagina (nome do menu ativo).
 */
exigir_login();
$usuario = usuario_logado();
$aviso   = aviso();
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= h($titulo) ?> | Farmali</title>
    <link rel="icon" href="assets/img/logo.png">
    <link rel="stylesheet" href="assets/css/estilo.css">
</head>
<body>
<div class="layout">

    <!-- Menu lateral -->
    <aside class="menu">
        <a href="dashboard.php" class="menu-logo"><img src="assets/img/logo.png" alt="Farmali Farmácia"></a>
        <nav>
            <a href="dashboard.php" class="<?= $pagina === 'dashboard' ? 'ativo' : '' ?>">Visão geral</a>
            <a href="produtos.php"  class="<?= $pagina === 'produtos'  ? 'ativo' : '' ?>">Produtos</a>
            <?php if ($usuario['perfil'] === 'admin'): ?>
                <a href="usuarios.php" class="<?= $pagina === 'usuarios' ? 'ativo' : '' ?>">Usuários</a>
            <?php endif; ?>
        </nav>
    </aside>

    <main class="principal">
        <!-- Barra superior -->
        <header class="barra">
            <strong><?= h($titulo) ?></strong>
            <div class="barra-usuario">
                <span><?= h($usuario['nome']) ?> <small>(<?= h($usuario['perfil']) ?>)</small></span>
                <a class="btn btn-claro btn-pequeno" href="logout.php">Sair</a>
            </div>
        </header>

        <section class="conteudo">
            <?php if ($aviso): ?>
                <div class="aviso aviso-<?= h($aviso['tipo']) ?>"><?= h($aviso['msg']) ?></div>
            <?php endif; ?>
