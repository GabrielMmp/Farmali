<?php
/*
 * funcoes.php
 * Funções usadas por todas as páginas: sessão, segurança, formatação e avisos.
 */

require_once __DIR__ . '/../config/conexao.php';

// Inicia a sessão (guarda quem está logado)
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

/* Escapa texto antes de mostrar na tela (evita injeção de HTML/JS) */
function h($texto): string
{
    return htmlspecialchars((string) $texto, ENT_QUOTES, 'UTF-8');
}

/* Formata número como moeda brasileira: 1234.5 -> R$ 1.234,50 */
function moeda($valor): string
{
    return 'R$ ' . number_format((float) $valor, 2, ',', '.');
}

/* Redireciona para outra página e encerra o script */
function redirecionar(string $url): void
{
    header('Location: ' . $url);
    exit;
}

/*
 * Aviso de uma só exibição (mensagem de sucesso ou erro).
 * aviso('Salvo!')            -> guarda a mensagem
 * $a = aviso();              -> lê e apaga a mensagem
 */
function aviso(?string $mensagem = null, string $tipo = 'ok'): ?array
{
    if ($mensagem !== null) {
        $_SESSION['aviso'] = ['msg' => $mensagem, 'tipo' => $tipo];
        return null;
    }
    $a = $_SESSION['aviso'] ?? null;
    unset($_SESSION['aviso']);
    return $a;
}

/* Gera (ou reutiliza) o código secreto que protege os formulários (CSRF) */
function csrf_token(): string
{
    if (empty($_SESSION['csrf'])) {
        $_SESSION['csrf'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf'];
}

/* Campo escondido que vai dentro de todo formulário POST */
function csrf_campo(): string
{
    return '<input type="hidden" name="csrf" value="' . csrf_token() . '">';
}

/* Confere se o formulário enviado é legítimo; senão, interrompe */
function csrf_validar(): void
{
    $enviado = $_POST['csrf'] ?? '';
    if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !hash_equals($_SESSION['csrf'] ?? '', $enviado)) {
        http_response_code(400);
        die('Requisição inválida. Volte e tente novamente.');
    }
}

/* Retorna os dados do usuário logado (ou null) */
function usuario_logado(): ?array
{
    return $_SESSION['usuario'] ?? null;
}

/* Barra quem não fez login */
function exigir_login(): void
{
    if (!usuario_logado()) {
        redirecionar('login.php');
    }
}

/* Barra quem não é administrador */
function exigir_admin(): void
{
    exigir_login();
    if (usuario_logado()['perfil'] !== 'admin') {
        aviso('Acesso restrito a administradores.', 'erro');
        redirecionar('dashboard.php');
    }
}

/* Lista as categorias (tipos de produto) para menus e filtros */
function listar_categorias(): array
{
    return conectar()->query('SELECT id, nome, icone FROM categorias ORDER BY nome')->fetchAll();
}
