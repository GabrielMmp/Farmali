<?php
/* usuario_excluir.php - Exclui um usuário (DELETE). Só admin, só POST. */
require_once __DIR__ . '/includes/funcoes.php';
exigir_admin();
csrf_validar();

$id = (int) ($_POST['id'] ?? 0);

if ($id === usuario_logado()['id']) {
    aviso('Você não pode excluir a própria conta.', 'erro');
} elseif ($id > 0) {
    $stmt = conectar()->prepare('DELETE FROM usuarios WHERE id = :id');
    $stmt->execute([':id' => $id]);
    aviso($stmt->rowCount() ? 'Usuário excluído.' : 'Usuário não encontrado.', $stmt->rowCount() ? 'ok' : 'erro');
}
redirecionar('usuarios.php');
