<?php
/* usuarios.php - Lista de usuários (READ). Só o administrador acessa. */
require_once __DIR__ . '/includes/funcoes.php';
exigir_admin();

$usuarios = conectar()
    ->query('SELECT id, nome, email, perfil, ativo, criado_em FROM usuarios ORDER BY nome')
    ->fetchAll();

$meuId  = usuario_logado()['id'];
$titulo = 'Usuários';
$pagina = 'usuarios';
require __DIR__ . '/includes/topo.php';
?>

<div class="cabecalho">
    <div>
        <h1>Usuários</h1>
        <p class="sub">Quem pode acessar o sistema da farmácia.</p>
    </div>
    <a class="btn btn-primario" href="usuario_form.php">+ Novo usuário</a>
</div>

<div class="painel">
    <div class="tabela-area">
        <table>
            <thead><tr><th>Nome</th><th>E-mail</th><th>Perfil</th><th>Situação</th><th>Ações</th></tr></thead>
            <tbody>
            <?php foreach ($usuarios as $u): ?>
                <tr>
                    <td><?= h($u['nome']) ?><?= (int) $u['id'] === $meuId ? ' <small>(você)</small>' : '' ?></td>
                    <td><?= h($u['email']) ?></td>
                    <td><span class="etiqueta"><?= h($u['perfil']) ?></span></td>
                    <td><span class="etiqueta <?= $u['ativo'] ? '' : 'baixo' ?>"><?= $u['ativo'] ? 'Ativo' : 'Inativo' ?></span></td>
                    <td>
                        <div class="acoes">
                            <a class="btn btn-claro btn-pequeno" href="usuario_form.php?id=<?= (int) $u['id'] ?>">Editar</a>
                            <?php if ((int) $u['id'] !== $meuId): ?>
                                <form method="post" action="usuario_excluir.php" onsubmit="return confirm('Deseja excluir este usuário?')">
                                    <?= csrf_campo() ?>
                                    <input type="hidden" name="id" value="<?= (int) $u['id'] ?>">
                                    <button class="btn btn-perigo btn-pequeno" type="submit">Excluir</button>
                                </form>
                            <?php endif; ?>
                        </div>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<?php require __DIR__ . '/includes/rodape.php'; ?>
