<?php
/* produto_form.php - Formulário para CADASTRAR (CREATE) ou EDITAR (UPDATE) um produto */
require_once __DIR__ . '/includes/funcoes.php';
exigir_login();

$pdo = conectar();
$id  = (int) ($_GET['id'] ?? $_POST['id'] ?? 0);

// Valores iniciais do formulário (vazio = novo produto)
$p = ['nome' => '', 'categoria_id' => 0, 'preco' => '', 'estoque' => '', 'descricao' => ''];

// Se veio um id, carrega o produto existente para edição
if ($id > 0) {
    $stmt = $pdo->prepare('SELECT nome, categoria_id, preco, estoque, descricao FROM produtos WHERE id = :id');
    $stmt->execute([':id' => $id]);
    $encontrado = $stmt->fetch();
    if (!$encontrado) {
        aviso('Produto não encontrado.', 'erro');
        redirecionar('produtos.php');
    }
    $p = $encontrado;
}

$categorias = listar_categorias();
$erros = [];

// Quando o formulário é enviado: valida e salva
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_validar();

    $p['nome']         = trim($_POST['nome'] ?? '');
    $p['categoria_id'] = (int) ($_POST['categoria_id'] ?? 0);
    $p['preco']        = trim($_POST['preco'] ?? '');
    $p['estoque']      = trim($_POST['estoque'] ?? '');
    $p['descricao']    = trim($_POST['descricao'] ?? '');

    // Aceita vírgula como separador decimal (ex.: 12,50)
    $preco   = str_replace(',', '.', $p['preco']);
    $estoque = filter_var($p['estoque'], FILTER_VALIDATE_INT, ['options' => ['min_range' => 0]]);

    // Confere se a categoria escolhida existe
    $ids = array_column($categorias, 'id');
    if ($p['nome'] === '' || mb_strlen($p['nome']) > 90)  $erros[] = 'Informe o nome (até 90 caracteres).';
    if (!in_array($p['categoria_id'], array_map('intval', $ids), true)) $erros[] = 'Escolha um tipo de produto.';
    if (!is_numeric($preco) || $preco < 0 || $preco > 99999999.99)    $erros[] = 'Informe um preço válido.';
    if ($estoque === false)                                           $erros[] = 'Informe uma quantidade de estoque válida.';

    if (!$erros) {
        if ($id > 0) {
            // UPDATE: atualiza o produto existente
            $stmt = $pdo->prepare(
                'UPDATE produtos
                    SET nome = :nome, categoria_id = :cat, preco = :preco, estoque = :est, descricao = :desc
                  WHERE id = :id'
            );
            $stmt->execute([
                ':nome' => $p['nome'], ':cat' => $p['categoria_id'], ':preco' => $preco,
                ':est'  => $estoque,   ':desc' => $p['descricao'],  ':id' => $id,
            ]);
            aviso('Produto atualizado!');
        } else {
            // INSERT: cria um produto novo
            $stmt = $pdo->prepare(
                'INSERT INTO produtos (nome, categoria_id, preco, estoque, descricao)
                 VALUES (:nome, :cat, :preco, :est, :desc)'
            );
            $stmt->execute([
                ':nome' => $p['nome'], ':cat' => $p['categoria_id'], ':preco' => $preco,
                ':est'  => $estoque,   ':desc' => $p['descricao'],
            ]);
            aviso('Produto cadastrado!');
        }
        redirecionar('produtos.php');
    }
}

$titulo = $id > 0 ? 'Editar produto' : 'Novo produto';
$pagina = 'produtos';
require __DIR__ . '/includes/topo.php';
?>

<div class="cabecalho">
    <div>
        <h1><?= h($titulo) ?></h1>
        <p class="sub">Preencha os dados do produto.</p>
    </div>
</div>

<div class="painel formulario">
    <?php foreach ($erros as $e): ?><div class="aviso aviso-erro"><?= h($e) ?></div><?php endforeach; ?>

    <form method="post">
        <?= csrf_campo() ?>
        <input type="hidden" name="id" value="<?= $id ?>">

        <div class="campo">
            <label for="nome">Nome do produto</label>
            <input id="nome" name="nome" maxlength="90" required value="<?= h($p['nome']) ?>">
        </div>

        <div class="duas-colunas">
            <div class="campo">
                <label for="categoria_id">Tipo</label>
                <select id="categoria_id" name="categoria_id" required>
                    <option value="">Selecione...</option>
                    <?php foreach ($categorias as $c): ?>
                        <option value="<?= (int) $c['id'] ?>" <?= (int) $p['categoria_id'] === (int) $c['id'] ? 'selected' : '' ?>><?= h($c['nome']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="campo">
                <label for="preco">Preço (R$)</label>
                <input id="preco" name="preco" type="number" min="0" step="0.01" required value="<?= h($p['preco']) ?>">
            </div>
        </div>

        <div class="campo">
            <label for="estoque">Quantidade em estoque</label>
            <input id="estoque" name="estoque" type="number" min="0" step="1" required value="<?= h($p['estoque']) ?>">
        </div>

        <div class="campo">
            <label for="descricao">Descrição</label>
            <textarea id="descricao" name="descricao" rows="4"><?= h($p['descricao']) ?></textarea>
        </div>

        <div class="acoes">
            <a class="btn btn-claro" href="produtos.php">Cancelar</a>
            <button class="btn btn-primario" type="submit">Salvar produto</button>
        </div>
    </form>
</div>

<?php require __DIR__ . '/includes/rodape.php'; ?>
