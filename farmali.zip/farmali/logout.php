<?php
/* logout.php - Encerra a sessão e volta para o login */
require_once __DIR__ . '/includes/funcoes.php';
$_SESSION = [];
session_destroy();
redirecionar('login.php');
