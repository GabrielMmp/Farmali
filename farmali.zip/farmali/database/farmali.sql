-- ============================================================
-- FARMALI - Banco de dados relacional (MySQL / MariaDB)
-- Importe este arquivo no phpMyAdmin (aba "Importar").
-- Ele cria o banco, as tabelas e os dados iniciais.
-- ============================================================

CREATE DATABASE IF NOT EXISTS farmali
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE farmali;

-- Apaga as tabelas antigas (filhas primeiro, por causa da chave estrangeira)
DROP TABLE IF EXISTS produtos;
DROP TABLE IF EXISTS categorias;
DROP TABLE IF EXISTS usuarios;

-- ------------------------------------------------------------
-- USUARIOS: quem pode entrar no sistema
-- perfil: 'admin' gerencia usuarios e produtos; 'funcionario' so produtos
-- ------------------------------------------------------------
CREATE TABLE usuarios (
  id         INT UNSIGNED NOT NULL AUTO_INCREMENT,
  nome       VARCHAR(80)  NOT NULL,
  email      VARCHAR(120) NOT NULL,
  senha_hash VARCHAR(255) NOT NULL,
  perfil     ENUM('admin','funcionario') NOT NULL DEFAULT 'funcionario',
  ativo      TINYINT(1)   NOT NULL DEFAULT 1,
  criado_em  TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_usuarios_email (email)
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- CATEGORIAS: os 5 tipos de produto e o SVG de cada um
-- ------------------------------------------------------------
CREATE TABLE categorias (
  id    INT UNSIGNED NOT NULL AUTO_INCREMENT,
  nome  VARCHAR(40)  NOT NULL,
  icone VARCHAR(60)  NOT NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uq_categorias_nome (nome)
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- PRODUTOS: cada produto pertence a UMA categoria (relacionamento 1:N)
-- ------------------------------------------------------------
CREATE TABLE produtos (
  id            INT UNSIGNED  NOT NULL AUTO_INCREMENT,
  nome          VARCHAR(90)   NOT NULL,
  categoria_id  INT UNSIGNED  NOT NULL,
  preco         DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  estoque       INT UNSIGNED  NOT NULL DEFAULT 0,
  descricao     TEXT          NULL,
  criado_em     TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  atualizado_em TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_produtos_categoria (categoria_id),
  KEY idx_produtos_nome (nome),
  CONSTRAINT fk_produtos_categoria FOREIGN KEY (categoria_id)
    REFERENCES categorias (id)
    ON UPDATE CASCADE ON DELETE RESTRICT
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- DADOS INICIAIS
-- Usuarios (senha de ambos: 123456)
-- ------------------------------------------------------------
INSERT INTO usuarios (nome, email, senha_hash, perfil) VALUES
('Administrador', 'admin@farmali.com',       '$2y$12$9SmIcHoOqknUGscRPLofmOeHjhIje1fZ36QDAfYYyZtKmC32SeT3a', 'admin'),
('Maria Atendente', 'funcionario@farmali.com', '$2y$12$9SmIcHoOqknUGscRPLofmOeHjhIje1fZ36QDAfYYyZtKmC32SeT3a', 'funcionario');

INSERT INTO categorias (id, nome, icone) VALUES
(1, 'Medicamento', 'medicamento.svg'),
(2, 'Utensílios',  'utensilios.svg'),
(3, 'Higiene',     'higiene.svg'),
(4, 'Beleza',      'beleza.svg'),
(5, 'Vitaminas',   'vitaminas.svg');

INSERT INTO produtos (nome, categoria_id, preco, estoque, descricao) VALUES
('Dipirona 500mg',        1,  8.90, 45, 'Analgésico e antitérmico. Embalagem com 10 comprimidos.'),
('Paracetamol 750mg',     1, 12.50, 32, 'Analgésico e antitérmico. Embalagem com 20 comprimidos.'),
('Soro Fisiológico 0,9%', 1,  5.90, 50, 'Solução fisiológica, frasco de 100ml.'),
('Vitamina C 1g',         5, 19.90, 18, 'Suplemento de vitamina C em comprimidos efervescentes.'),
('Shampoo Neutro',        3, 16.90, 24, 'Shampoo para uso diário, frasco de 350ml.'),
('Sabonete Líquido',      3, 11.90, 40, 'Sabonete líquido para mãos e corpo, 250ml.'),
('Álcool 70%',            3,  7.50, 28, 'Álcool 70% para higienização, frasco de 500ml.'),
('Protetor Solar FPS 50', 4, 42.90, 12, 'Protetor solar facial e corporal, 120ml.'),
('Creme Hidratante',      4, 24.90, 15, 'Creme hidratante corporal, 200g.'),
('Curativo Adesivo',      2,  6.90, 60, 'Curativos adesivos sortidos, caixa com 10 unidades.'),
('Termômetro Digital',    2, 29.90,  8, 'Termômetro clínico digital com display e alarme de febre.'),
('Complexo B',            5, 27.50, 22, 'Suplemento de vitaminas do complexo B, 60 cápsulas.');
