<?php
/* dashboard.php - Visão geral: indicadores de estoque calculados no banco */
require_once __DIR__ . '/includes/funcoes.php';
exigir_login();

$pdo = conectar();

// Totais gerais (uma única consulta com funções de agregação)
$resumo = $pdo->query(
    'SELECT COUNT(*)                          AS total,
            COALESCE(SUM(estoque), 0)         AS unidades,
            COALESCE(SUM(estoque < 10), 0)    AS baixo,
            COALESCE(SUM(preco * estoque), 0) AS valor
       FROM produtos'
)->fetch();

// Quantidade de produtos em cada categoria (LEFT JOIN mostra também as vazias)
$porCategoria = $pdo->query(
    'SELECT c.id, c.nome, c.icone, COUNT(p.id) AS qtd
       FROM categorias c
       LEFT JOIN produtos p ON p.categoria_id = c.id
      GROUP BY c.id, c.nome, c.icone
      ORDER BY c.nome'
)->fetchAll();

// Últimos 5 produtos cadastrados
$recentes = $pdo->query(
    'SELECT p.nome, p.preco, p.estoque, c.nome AS categoria
       FROM produtos p
       JOIN categorias c ON c.id = p.categoria_id
      ORDER BY p.id DESC
      LIMIT 5'
)->fetchAll();

$titulo = 'Visão geral';
$pagina = 'dashboard';
require __DIR__ . '/includes/topo.php';
?>

<div class="cabecalho">
    <div>
        <h1>Visão geral</h1>
        <p class="sub">Acompanhe os principais dados do seu estoque.</p>
    </div>
    <a class="btn btn-primario" href="produto_form.php">+ Novo produto</a>
</div>

<div class="stats">
    <div class="stat"><span>Produtos cadastrados</span><strong><?= (int) $resumo['total'] ?></strong></div>
    <div class="stat"><span>Unidades em estoque</span><strong><?= (int) $resumo['unidades'] ?></strong></div>
    <div class="stat"><span>Estoque baixo (&lt; 10)</span><strong><?= (int) $resumo['baixo'] ?></strong></div>
    <div class="stat"><span>Valor em estoque</span><strong><?= moeda($resumo['valor']) ?></strong></div>
</div>

<div class="painel">
    <h2>Produtos por tipo</h2>
    <div class="tipos">
        <?php foreach ($porCategoria as $c): ?>
            <a class="tipo" href="produtos.php?categoria=<?= (int) $c['id'] ?>">
                <img src="assets/img/tipos/<?= h($c['icone']) ?>" alt="">
                <strong><?= h($c['nome']) ?></strong>
                <small><?= (int) $c['qtd'] ?> produto(s)</small>
            </a>
        <?php endforeach; ?>
    </div>
</div>

<div class="painel">
    <h2>Últimos produtos cadastrados</h2>
    <div class="tabela-area">
        <table>
            <thead><tr><th>Produto</th><th>Tipo</th><th>Preço</th><th>Estoque</th></tr></thead>
            <tbody>
            <?php foreach ($recentes as $p): ?>
                <tr>
                    <td><?= h($p['nome']) ?></td>
                    <td><?= h($p['categoria']) ?></td>
                    <td><?= moeda($p['preco']) ?></td>
                    <td><span class="etiqueta <?= $p['estoque'] < 10 ? 'baixo' : '' ?>"><?= (int) $p['estoque'] ?> un.</span></td>
                </tr>
            <?php endforeach; ?>
            <?php if (!$recentes): ?><tr><td colspan="4">Nenhum produto cadastrado.</td></tr><?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php require __DIR__ . '/includes/rodape.php'; ?>
