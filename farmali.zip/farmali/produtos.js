document.addEventListener("DOMContentLoaded", function () {
    const busca = document.getElementById("campoBusca");
    const formularioBusca = document.querySelector(".busca-site");
    const campoCategoria = document.getElementById("categoriaBusca");
    const cards = [...document.querySelectorAll(".cartao-produto")];
    const resultado = document.getElementById("resultadoBusca");
    const semResultado = document.getElementById("mensagemSemResultado");
    const botoesCategoria = [...document.querySelectorAll("[data-category-filter]")];
    let categoria = campoCategoria?.value || "";

    function normalizar(valor) {
        return String(valor || "").normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLocaleLowerCase("pt-BR").trim();
    }

    function filtrar() {
        const termo = normalizar(busca?.value || "");
        const categoriaNormalizada = normalizar(categoria);
        let quantidadeVisivel = 0;

        cards.forEach(card => {
            const conteudo = normalizar([
                card.dataset.nome,
                card.dataset.categoria,
                card.dataset.descricao
            ].join(" "));
            const correspondeBusca = !termo || conteudo.includes(termo);
            const correspondeCategoria = !categoriaNormalizada || normalizar(card.dataset.categoria) === categoriaNormalizada;
            const visivel = correspondeBusca && correspondeCategoria;
            card.hidden = !visivel;
            if (visivel) quantidadeVisivel++;
        });

        if (resultado) resultado.textContent = quantidadeVisivel + " produto(s)";
        if (semResultado) semResultado.hidden = quantidadeVisivel !== 0;
        if (campoCategoria) campoCategoria.value = categoria;
    }

    botoesCategoria.forEach(botao => {
        botao.addEventListener("click", () => {
            categoria = botao.dataset.categoryFilter || "";
            botoesCategoria.forEach(item => item.classList.toggle("ativa", item === botao));
            filtrar();
        });
    });

    busca?.addEventListener("input", filtrar);
    formularioBusca?.addEventListener("submit", () => {
        if (campoCategoria) campoCategoria.value = categoria;
    });

    async function atualizarContador() {
        try {
            const resposta = await fetch("carrinho_contagem.php", { headers: { "Accept": "application/json" } });
            if (!resposta.ok) return;
            const dados = await resposta.json();
            document.querySelectorAll(".contadorCarrinhoTopo").forEach(item => {
                item.textContent = dados.total_itens ?? 0;
            });
        } catch (erro) {
            // O catálogo continua funcionando mesmo se o contador falhar.
        }
    }

    cards.forEach(card => {
        const menos = card.querySelector(".diminuir");
        const mais = card.querySelector(".aumentar");
        const quantidade = card.querySelector(".quantidade");
        const botaoCarrinho = card.querySelector(".botao-carrinho");
        if (!botaoCarrinho || !quantidade) return;

        const estoque = Number(botaoCarrinho.dataset.estoque || 0);
        if (estoque <= 0) {
            botaoCarrinho.disabled = true;
            botaoCarrinho.textContent = "Sem estoque";
            if (mais) mais.disabled = true;
            if (menos) menos.disabled = true;
        }

        menos?.addEventListener("click", () => {
            const atual = Number(quantidade.textContent || 1);
            if (atual > 1) quantidade.textContent = String(atual - 1);
        });

        mais?.addEventListener("click", () => {
            const atual = Number(quantidade.textContent || 1);
            if (atual < estoque) quantidade.textContent = String(atual + 1);
        });

        botaoCarrinho.addEventListener("click", async () => {
            const qtd = Number(quantidade.textContent || 1);
            if (qtd < 1 || qtd > estoque) {
                alert("Quantidade indisponível no estoque.");
                return;
            }
            botaoCarrinho.disabled = true;
            try {
                const corpo = new URLSearchParams({ id: botaoCarrinho.dataset.id, quantidade: String(qtd) });
                const resposta = await fetch("adicionar_carrinho.php", {
                    method: "POST",
                    headers: { "Content-Type": "application/x-www-form-urlencoded", "Accept": "application/json" },
                    body: corpo
                });
                const dados = await resposta.json();
                if (!resposta.ok || !dados.ok) throw new Error(dados.mensagem || "Não foi possível adicionar ao carrinho.");
                await atualizarContador();
                botaoCarrinho.innerHTML = '<i class="fa-solid fa-check"></i> Adicionado';
                window.setTimeout(() => {
                    botaoCarrinho.innerHTML = '<i class="fa-solid fa-cart-plus"></i> Adicionar ao carrinho';
                    botaoCarrinho.disabled = estoque <= 0;
                }, 1200);
            } catch (erro) {
                alert(erro.message);
                botaoCarrinho.disabled = estoque <= 0;
            }
        });
    });

    filtrar();
    atualizarContador();
});
