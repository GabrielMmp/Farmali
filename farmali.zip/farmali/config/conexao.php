<?php
/*
 * conexao.php
 * Dados de acesso ao MySQL e função que abre a conexão (PDO).
 * No WAMP o padrão é usuário "root" e senha vazia.
 */

const DB_HOST    = 'localhost';
const DB_NOME    = 'farmali';
const DB_USUARIO = 'root';
const DB_SENHA   = '';

/* Abre a conexão uma única vez e reaproveita nas próximas chamadas */
function conectar(): PDO
{
    static $pdo = null;

    if ($pdo === null) {
        try {
            $pdo = new PDO(
                'mysql:host=' . DB_HOST . ';dbname=' . DB_NOME . ';charset=utf8mb4',
                DB_USUARIO,
                DB_SENHA,
                [
                    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,  // mostra erros de SQL
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,        // resultados como array
                    PDO::ATTR_EMULATE_PREPARES   => false,                   // prepared statements reais
                ]
            );
        } catch (PDOException $e) {
            http_response_code(500);
            die('Não foi possível conectar ao banco de dados. '
              . 'Verifique se o MySQL do WAMP está ligado, se importou o arquivo '
              . 'database/farmali.sql e se os dados em config/conexao.php estão corretos.');
        }
    }
    return $pdo;
}
