<?php
/* index.php - Porta de entrada: manda para o painel ou para o login */
require_once __DIR__ . '/includes/funcoes.php';
redirecionar(usuario_logado() ? 'dashboard.php' : 'login.php');
