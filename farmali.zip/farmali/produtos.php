<?php
/* produtos.php - Lista de produtos (READ) com pesquisa, filtro e ordenação */
require_once __DIR__ . '/includes/funcoes.php';
exigir_login();

// Valores vindos da barra de pesquisa (método GET)
$busca     = trim($_GET['busca'] ?? '');
$categoria = (int) ($_GET['categoria'] ?? 0);
$ordem     = $_GET['ordem'] ?? 'recentes';

// Só aceita ordenações da lista abaixo (evita SQL injection no ORDER BY)
$ordens = [
    'recentes'    => 'p.id DESC',
    'nome'        => 'p.nome ASC',
    'preco-menor' => 'p.preco ASC',
    'preco-maior' => 'p.preco DESC',
];
if (!isset($ordens[$ordem])) {
    $ordem = 'recentes';
}

// Monta o WHERE conforme os filtros usados
$where  = [];
$params = [];
if ($busca !== '') {
    $like = '%' . addcslashes($busca, '%_\\') . '%';
    $where[] = '(p.nome LIKE :b1 OR p.descricao LIKE :b2 OR c.nome LIKE :b3)';
    $params[':b1'] = $params[':b2'] = $params[':b3'] = $like;
}
if ($categoria > 0) {
    $where[] = 'p.categoria_id = :cat';
    $params[':cat'] = $categoria;
}

$sql = 'SELECT p.id, p.nome, p.preco, p.estoque, p.descricao, c.nome AS categoria, c.icone
          FROM produtos p
          JOIN categorias c ON c.id = p.categoria_id'
     . ($where ? ' WHERE ' . implode(' AND ', $where) : '')
     . ' ORDER BY ' . $ordens[$ordem];

$stmt = conectar()->prepare($sql);
$stmt->execute($params);
$produtos = $stmt->fetchAll();

$categorias = listar_categorias();
$titulo = 'Produtos';
$pagina = 'produtos';
require __DIR__ . '/includes/topo.php';
?>

<div class="cabecalho">
    <div>
        <h1>Produtos</h1>
        <p class="sub">Consulte, pesquise e mantenha seu catálogo atualizado.</p>
    </div>
    <a class="btn btn-primario" href="produto_form.php">+ Novo produto</a>
</div>

<div class="painel">
    <!-- Pesquisa e filtros -->
    <form class="filtros" method="get">
        <input type="search" name="busca" value="<?= h($busca) ?>" placeholder="Pesquisar por nome, descrição ou tipo...">
        <select name="categoria">
            <option value="0">Todos os tipos</option>
            <?php foreach ($categorias as $c): ?>
                <option value="<?= (int) $c['id'] ?>" <?= $categoria === (int) $c['id'] ? 'selected' : '' ?>><?= h($c['nome']) ?></option>
            <?php endforeach; ?>
        </select>
        <select name="ordem">
            <option value="recentes"    <?= $ordem === 'recentes'    ? 'selected' : '' ?>>Mais recentes</option>
            <option value="nome"        <?= $ordem === 'nome'        ? 'selected' : '' ?>>Nome A–Z</option>
            <option value="preco-menor" <?= $ordem === 'preco-menor' ? 'selected' : '' ?>>Menor preço</option>
            <option value="preco-maior" <?= $ordem === 'preco-maior' ? 'selected' : '' ?>>Maior preço</option>
        </select>
        <button class="btn btn-primario" type="submit">Filtrar</button>
        <a class="btn btn-claro" href="produtos.php">Limpar</a>
    </form>

    <p class="sub"><?= count($produtos) ?> produto(s) encontrado(s)</p>

    <!-- Cartões de produto -->
    <div class="grade">
        <?php foreach ($produtos as $p): ?>
            <article class="cartao">
                <img src="assets/img/tipos/<?= h($p['icone']) ?>" alt="<?= h($p['categoria']) ?>">
                <div class="cartao-info">
                    <span class="etiqueta"><?= h($p['categoria']) ?></span>
                    <h3><?= h($p['nome']) ?></h3>
                    <p class="descricao"><?= h($p['descricao']) ?></p>
                    <div class="cartao-preco">
                        <strong><?= moeda($p['preco']) ?></strong>
                        <small class="<?= $p['estoque'] < 10 ? 'texto-baixo' : '' ?>"><?= (int) $p['estoque'] ?> em estoque</small>
                    </div>
                    <div class="acoes">
                        <a class="btn btn-claro btn-pequeno" href="produto_form.php?id=<?= (int) $p['id'] ?>">Editar</a>
                        <form method="post" action="produto_excluir.php" onsubmit="return confirm('Deseja excluir este produto?')">
                            <?= csrf_campo() ?>
                            <input type="hidden" name="id" value="<?= (int) $p['id'] ?>">
                            <button class="btn btn-perigo btn-pequeno" type="submit">Excluir</button>
                        </form>
                    </div>
                </div>
            </article>
        <?php endforeach; ?>
        <?php if (!$produtos): ?>
            <div class="vazio">Nenhum produto encontrado. Tente outro termo ou tipo.</div>
        <?php endif; ?>
    </div>
</div>

<?php require __DIR__ . '/includes/rodape.php'; ?>
