# FARMALI — PHP + MySQL (WAMP)

Sistema de gestão da farmácia Farmali com **banco de dados relacional**.
Produtos, categorias e usuários ficam no MySQL (nada de LocalStorage).

## Como instalar no WAMP

1. Copie a pasta `farmali` para `C:\wamp64\www\`
   (ficará `C:\wamp64\www\farmali`).
2. Inicie o WAMP (ícone verde na bandeja).
3. Abra o phpMyAdmin: http://localhost/phpmyadmin
4. Clique em **Importar** → escolha `database/farmali.sql` → **Importar**.
   Isso cria o banco `farmali`, as tabelas e os dados iniciais.
5. Se o seu MySQL tiver senha no `root`, edite `config/conexao.php`.
   (No WAMP o padrão é usuário `root` e senha vazia.)
6. Acesse: **http://localhost/farmali/**

## Acessos de demonstração

| Perfil        | E-mail                    | Senha  |
|---------------|---------------------------|--------|
| Administrador | admin@farmali.com         | 123456 |
| Funcionário   | funcionario@farmali.com   | 123456 |

- **Administrador**: gerencia produtos **e** usuários.
- **Funcionário**: gerencia somente produtos.

## Banco de dados (3 tabelas relacionadas)

```
categorias (1) ────< (N) produtos          usuarios
 id, nome, icone         id, nome, categoria_id (FK),   id, nome, email (único),
                         preco, estoque, descricao,     senha_hash, perfil, ativo
                         criado_em, atualizado_em
```

- Tipos de produto (categorias): **Medicamento, Utensílios, Higiene, Beleza, Vitaminas**.
- Cada categoria tem um SVG em `assets/img/tipos/`, usado nos cartões dos produtos.
- A chave estrangeira impede excluir uma categoria que tenha produtos.

## CRUD

| Parte    | Criar / Editar      | Listar         | Excluir               |
|----------|---------------------|----------------|-----------------------|
| Produtos | `produto_form.php`  | `produtos.php` | `produto_excluir.php` |
| Usuários | `usuario_form.php`  | `usuarios.php` | `usuario_excluir.php` |

## Organização dos arquivos

```
farmali/
├── index.php            entrada (vai para login ou painel)
├── login.php / logout.php
├── dashboard.php        visão geral e indicadores
├── produtos.php         lista, pesquisa, filtro e ordenação
├── produto_form.php     cadastrar e editar produto
├── produto_excluir.php  excluir produto
├── usuarios.php         lista de usuários (admin)
├── usuario_form.php     cadastrar e editar usuário (admin)
├── usuario_excluir.php  excluir usuário (admin)
├── config/conexao.php   dados do MySQL e conexão PDO
├── includes/
│   ├── funcoes.php      sessão, segurança, formatação, avisos
│   ├── topo.php         menu e barra superior
│   └── rodape.php       fim da página
├── database/farmali.sql estrutura e dados iniciais
└── assets/
    ├── css/estilo.css   estilo (bordas verde e azul)
    └── img/             logo.png e tipos/*.svg
```

## Segurança aplicada

- Consultas preparadas (PDO) contra SQL Injection.
- Senhas guardadas com `password_hash` (nunca em texto).
- Token CSRF em todos os formulários que alteram dados.
- Saída escapada com `htmlspecialchars` (contra XSS).
- Exclusões somente por POST; admin não exclui nem rebaixa a si mesmo.

## Problemas comuns

- **"Não foi possível conectar"**: confira se o WAMP está verde, se importou o `.sql` e os dados de `config/conexao.php`.
- **Login não funciona**: reimporte o `farmali.sql` (ele recria as tabelas).
- **Acentos estranhos**: o banco usa `utf8mb4`; importe o `.sql` pelo phpMyAdmin sem alterar a codificação.
