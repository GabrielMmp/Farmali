<?php
/* usuario_form.php - Formulário para CADASTRAR (CREATE) ou EDITAR (UPDATE) um usuário */
require_once __DIR__ . '/includes/funcoes.php';
exigir_admin();

$pdo   = conectar();
$id    = (int) ($_GET['id'] ?? $_POST['id'] ?? 0);
$meuId = usuario_logado()['id'];

// Valores iniciais (novo usuário)
$u = ['nome' => '', 'email' => '', 'perfil' => 'funcionario', 'ativo' => 1];

// Edição: carrega o usuário do banco
if ($id > 0) {
    $stmt = $pdo->prepare('SELECT nome, email, perfil, ativo FROM usuarios WHERE id = :id');
    $stmt->execute([':id' => $id]);
    $encontrado = $stmt->fetch();
    if (!$encontrado) {
        aviso('Usuário não encontrado.', 'erro');
        redirecionar('usuarios.php');
    }
    $u = $encontrado;
}

// O administrador não pode tirar o próprio acesso (perfil/ativo ficam travados)
$travado = ($id === $meuId);
$erros   = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_validar();

    $u['nome']  = trim($_POST['nome'] ?? '');
    $u['email'] = trim($_POST['email'] ?? '');
    $senha      = $_POST['senha'] ?? '';
    if (!$travado) {
        $u['perfil'] = ($_POST['perfil'] ?? '') === 'admin' ? 'admin' : 'funcionario';
        $u['ativo']  = isset($_POST['ativo']) ? 1 : 0;
    }

    // Validações
    if ($u['nome'] === '' || mb_strlen($u['nome']) > 80)             $erros[] = 'Informe o nome (até 80 caracteres).';
    if (!filter_var($u['email'], FILTER_VALIDATE_EMAIL))             $erros[] = 'Informe um e-mail válido.';
    if ($id === 0 && strlen($senha) < 6)                             $erros[] = 'A senha deve ter pelo menos 6 caracteres.';
    if ($id > 0 && $senha !== '' && strlen($senha) < 6)              $erros[] = 'A nova senha deve ter pelo menos 6 caracteres.';

    if (!$erros) {
        try {
            if ($id > 0) {
                // UPDATE: só troca a senha se uma nova foi digitada
                $sql    = 'UPDATE usuarios SET nome = :nome, email = :email, perfil = :perfil, ativo = :ativo';
                $params = [':nome' => $u['nome'], ':email' => $u['email'], ':perfil' => $u['perfil'], ':ativo' => $u['ativo'], ':id' => $id];
                if ($senha !== '') {
                    $sql .= ', senha_hash = :senha';
                    $params[':senha'] = password_hash($senha, PASSWORD_DEFAULT);
                }
                $pdo->prepare($sql . ' WHERE id = :id')->execute($params);
                aviso('Usuário atualizado!');
            } else {
                // INSERT: a senha é guardada criptografada (hash), nunca em texto
                $pdo->prepare(
                    'INSERT INTO usuarios (nome, email, senha_hash, perfil, ativo)
                     VALUES (:nome, :email, :senha, :perfil, :ativo)'
                )->execute([
                    ':nome' => $u['nome'], ':email' => $u['email'],
                    ':senha' => password_hash($senha, PASSWORD_DEFAULT),
                    ':perfil' => $u['perfil'], ':ativo' => $u['ativo'],
                ]);
                aviso('Usuário cadastrado!');
            }
            // Mantém o nome atualizado na sessão se o usuário editou a si mesmo
            if ($travado) {
                $_SESSION['usuario']['nome']  = $u['nome'];
                $_SESSION['usuario']['email'] = $u['email'];
            }
            redirecionar('usuarios.php');
        } catch (PDOException $e) {
            // Código 23000 = violação de chave única (e-mail repetido)
            if ($e->getCode() === '23000') {
                $erros[] = 'Já existe um usuário com esse e-mail.';
            } else {
                throw $e;
            }
        }
    }
}

$titulo = $id > 0 ? 'Editar usuário' : 'Novo usuário';
$pagina = 'usuarios';
require __DIR__ . '/includes/topo.php';
?>

<div class="cabecalho">
    <div>
        <h1><?= h($titulo) ?></h1>
        <p class="sub">Preencha os dados de acesso.</p>
    </div>
</div>

<div class="painel formulario">
    <?php foreach ($erros as $e): ?><div class="aviso aviso-erro"><?= h($e) ?></div><?php endforeach; ?>

    <form method="post" autocomplete="off">
        <?= csrf_campo() ?>
        <input type="hidden" name="id" value="<?= $id ?>">

        <div class="campo">
            <label for="nome">Nome</label>
            <input id="nome" name="nome" maxlength="80" required value="<?= h($u['nome']) ?>">
        </div>

        <div class="campo">
            <label for="email">E-mail</label>
            <input id="email" name="email" type="email" maxlength="120" required value="<?= h($u['email']) ?>">
        </div>

        <div class="campo">
            <label for="senha"><?= $id > 0 ? 'Nova senha (deixe em branco para manter)' : 'Senha (mínimo 6 caracteres)' ?></label>
            <input id="senha" name="senha" type="password" <?= $id > 0 ? '' : 'required' ?>>
        </div>

        <div class="duas-colunas">
            <div class="campo">
                <label for="perfil">Perfil</label>
                <select id="perfil" name="perfil" <?= $travado ? 'disabled' : '' ?>>
                    <option value="funcionario" <?= $u['perfil'] === 'funcionario' ? 'selected' : '' ?>>Funcionário</option>
                    <option value="admin"       <?= $u['perfil'] === 'admin'       ? 'selected' : '' ?>>Administrador</option>
                </select>
            </div>
            <div class="campo campo-check">
                <label>
                    <input type="checkbox" name="ativo" value="1" <?= $u['ativo'] ? 'checked' : '' ?> <?= $travado ? 'disabled' : '' ?>>
                    Usuário ativo
                </label>
            </div>
        </div>
        <?php if ($travado): ?><p class="sub">Você não pode alterar o próprio perfil ou desativar a própria conta.</p><?php endif; ?>

        <div class="acoes">
            <a class="btn btn-claro" href="usuarios.php">Cancelar</a>
            <button class="btn btn-primario" type="submit">Salvar usuário</button>
        </div>
    </form>
</div>

<?php require __DIR__ . '/includes/rodape.php'; ?>
