<?php
header('Location: ../produtos.php', true, 302);
exit;
