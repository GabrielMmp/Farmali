<?php
/**
 * Cria as categorias e os produtos demonstrativos da Farmali sem duplicar registros.
 * Os preços e estoques iniciais são valores de demonstração e podem ser editados no banco.
 */
function garantirProdutosFarmali(PDO $conexao): void
{
    $catalogo = [
        'Medicamentos' => [
            ['Dorflex', 'Medicamento de referência para demonstração do catálogo.', 12.90],
            ['ENO', 'Antiácido efervescente. Apresentação demonstrativa.', 8.90],
            ['Novalgina', 'Medicamento de referência para demonstração do catálogo.', 16.90],
            ['Cimegripe', 'Medicamento de referência para demonstração do catálogo.', 14.90],
            ['Neosaldina', 'Medicamento de referência para demonstração do catálogo.', 18.90],
        ],
        'Utensílios' => [
            ['Cotonete', 'Hastes flexíveis com pontas de algodão.', 5.90],
            ['Algodão', 'Algodão para cuidados e uso externo.', 7.50],
            ['Band-eid', 'Curativos adesivos para pequenos ferimentos.', 9.90],
            ['Gazes', 'Gazes para curativos e cuidados externos.', 6.90],
            ['Lancetas', 'Lancetas para dispositivos de punção compatíveis.', 12.90],
        ],
        'Higiene' => [
            ['Escova de dente', 'Escova dental para higiene bucal diária.', 8.90],
            ['Creme dental', 'Creme dental para higiene bucal diária.', 6.90],
            ['Enxaguante bucal', 'Enxaguante para complementar a higiene bucal.', 14.90],
            ['Lâmina de barbear', 'Lâminas para barbear.', 7.90],
            ['Shampoo', 'Produto para limpeza dos cabelos.', 18.90],
            ['Condicionador', 'Produto para cuidado e condicionamento dos cabelos.', 19.90],
            ['Sabonete', 'Sabonete para higiene pessoal.', 3.90],
        ],
        'Beleza' => [
            ['Gel de cabelo', 'Gel para modelar e finalizar os cabelos.', 12.90],
            ['Creme de pentear', 'Creme para pentear e finalizar os cabelos.', 16.90],
            ['Batom', 'Produto cosmético para os lábios.', 14.90],
            ['Maquiagem', 'Produto de maquiagem. Consulte a apresentação disponível.', 24.90],
            ['Unhas coláveis', 'Unhas postiças autocolantes.', 19.90],
        ],
        'Vitaminas' => [
            ['Vitaxon C', 'Produto vitamínico de referência para demonstração do catálogo.', 19.90],
            ['Citoneurin', 'Produto de referência para demonstração do catálogo.', 29.90],
            ['Redoxon', 'Produto vitamínico de referência para demonstração do catálogo.', 22.90],
            ['Dprev', 'Produto de referência para demonstração do catálogo.', 25.90],
            ['ADE Forte', 'Produto de referência para demonstração do catálogo.', 21.90],
        ],
    ];

    $conexao->beginTransaction();
    try {
        $buscarCategoria = $conexao->prepare('SELECT COD_CATEGORIA FROM CATEGORIA WHERE NOME = ? LIMIT 1');
        $inserirCategoria = $conexao->prepare('INSERT INTO CATEGORIA (NOME, DESCRICAO, STATUS) VALUES (?, ?, \'ATIVO\')');
        $buscarProduto = $conexao->prepare('SELECT COD_PRODUTO FROM PRODUTO WHERE COD_CATEGORIA_FK = ? AND NOME = ? LIMIT 1');
        $inserirProduto = $conexao->prepare(
            "INSERT INTO PRODUTO (NOME, DESCRICAO, PRECO, QUANTIDADE_ESTOQUE, COD_CATEGORIA_FK, STATUS)
             VALUES (?, ?, ?, 25, ?, 'ATIVO')"
        );

        foreach ($catalogo as $nomeCategoria => $itens) {
            $buscarCategoria->execute([$nomeCategoria]);
            $codigoCategoria = $buscarCategoria->fetchColumn();

            if (!$codigoCategoria) {
                $inserirCategoria->execute([$nomeCategoria, 'Produtos da categoria ' . $nomeCategoria . '.']);
                $codigoCategoria = (int) $conexao->lastInsertId();
            }

            foreach ($itens as [$nome, $descricao, $preco]) {
                $buscarProduto->execute([$codigoCategoria, $nome]);
                if (!$buscarProduto->fetchColumn()) {
                    $inserirProduto->execute([$nome, $descricao, $preco, $codigoCategoria]);
                }
            }
        }

        $conexao->commit();
    } catch (Throwable $erro) {
        if ($conexao->inTransaction()) {
            $conexao->rollBack();
        }
        throw $erro;
    }
}
