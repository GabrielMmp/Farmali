
<?php

$servidor = "sql107.infinityfree.com";
$porta = 3306;
$banco = "if0_43513263_farmali";
$usuario = "if0_43513263";
$senha = "farmali123456";

try {
    $conexao = new PDO(
        "mysql:host=$servidor;port=$porta;dbname=$banco;charset=utf8mb4",
        $usuario,
        $senha
    );

    $conexao->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    echo "Conexão realizada com sucesso!";

} catch (PDOException $erro) {
    die("Erro ao conectar: " . htmlspecialchars($erro->getMessage(), ENT_QUOTES, 'UTF-8'));
}

?>
