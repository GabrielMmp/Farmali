<?php
require_once __DIR__.'/includes.php'; exigir_perfil(['cliente','funcionario','admin']);
$uid=usuario()['id'];$s=$conexao->prepare('SELECT p.COD_PRODUTO,p.NOME,p.PRECO,p.QUANTIDADE_ESTOQUE,c.QUANTIDADE FROM CARRINHO c JOIN PRODUTO p ON p.COD_PRODUTO=c.COD_PRODUTO WHERE c.ID_USUARIO=?');$s->execute([$uid]);$itens=$s->fetchAll();if(!$itens){header('Location: carrinho.php');exit;}
$subtotal=0;foreach($itens as $i)$subtotal+=(float)$i['PRECO']*(int)$i['QUANTIDADE'];
$etapa=$_GET['etapa']??(isset($_SESSION['dados_compra'])?'pagamento':'dados');$erro='';
if($_SERVER['REQUEST_METHOD']==='POST' && ($_POST['acao']??'')==='dados'){
 $dados=['nome'=>trim($_POST['nome']??''),'email'=>trim($_POST['email']??''),'telefone'=>trim($_POST['telefone']??''),'cep'=>trim($_POST['cep']??''),'endereco'=>trim($_POST['endereco']??''),'numero'=>trim($_POST['numero']??''),'complemento'=>trim($_POST['complemento']??''),'cidade'=>trim($_POST['cidade']??''),'estado'=>trim($_POST['estado']??'')];
 if($dados['nome']===''||!filter_var($dados['email'],FILTER_VALIDATE_EMAIL)||$dados['telefone']===''||$dados['cep']===''||$dados['endereco']===''||$dados['numero']===''||$dados['cidade']===''||$dados['estado']==='')$erro='Preencha todos os dados obrigatórios e informe um e-mail válido.';
 else {$_SESSION['dados_compra']=$dados;header('Location: compra.php?etapa=pagamento');exit;}
}
if($_SERVER['REQUEST_METHOD']==='POST' && ($_POST['acao']??'')==='finalizar'){
 $d=$_SESSION['dados_compra']??null;$pagamento=$_POST['pagamento']??'';$entrega=$_POST['entrega']??'';
 if(!$d){header('Location: compra.php?etapa=dados');exit;}
 if(!in_array($pagamento,['pix','credito','debito','dinheiro'],true)||!in_array($entrega,['retirada','entrega'],true))$erro='Selecione uma forma de pagamento e uma opção de recebimento.';
 else {
  $frete=$entrega==='entrega'?10.00:0.00;$total=$subtotal+$frete;
  try{$conexao->beginTransaction();
   foreach($itens as $i){$s=$conexao->prepare("SELECT QUANTIDADE_ESTOQUE,STATUS FROM PRODUTO WHERE COD_PRODUTO=? FOR UPDATE");$s->execute([$i['COD_PRODUTO']]);$p=$s->fetch();if(!$p||$p['STATUS']!=='ATIVO'||(int)$p['QUANTIDADE_ESTOQUE']<(int)$i['QUANTIDADE'])throw new RuntimeException('Estoque insuficiente para '.$i['NOME'].'. Volte ao carrinho e ajuste a quantidade.');}
   $s=$conexao->prepare("INSERT INTO VENDA(ID_USUARIO,NOME_CLIENTE,EMAIL_CLIENTE,TELEFONE,CEP,ENDERECO,NUMERO,COMPLEMENTO,CIDADE,ESTADO,TIPO_ENTREGA,FRETE,FORMA_PAGAMENTO,SUBTOTAL,TOTAL) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
   $s->execute([$uid,$d['nome'],$d['email'],$d['telefone'],$d['cep'],$d['endereco'],$d['numero'],$d['complemento'],$d['cidade'],$d['estado'],$entrega,$frete,$pagamento,$subtotal,$total]);$venda=(int)$conexao->lastInsertId();
   foreach($itens as $i){$s=$conexao->prepare('INSERT INTO ITEM_VENDA(ID_VENDA,COD_PRODUTO,QUANTIDADE,PRECO_UNITARIO) VALUES(?,?,?,?)');$s->execute([$venda,$i['COD_PRODUTO'],$i['QUANTIDADE'],$i['PRECO']]);$s=$conexao->prepare('UPDATE PRODUTO SET QUANTIDADE_ESTOQUE=QUANTIDADE_ESTOQUE-? WHERE COD_PRODUTO=?');$s->execute([$i['QUANTIDADE'],$i['COD_PRODUTO']]);}
   $s=$conexao->prepare('DELETE FROM CARRINHO WHERE ID_USUARIO=?');$s->execute([$uid]);$conexao->commit();unset($_SESSION['dados_compra']);$_SESSION['venda_finalizada']=['id'=>$venda,'total'=>$total];header('Location: compra.php?sucesso=1');exit;
  }catch(Throwable $e){if($conexao->inTransaction())$conexao->rollBack();$erro=$e->getMessage();}
 }
}
if(isset($_GET['sucesso'])&&isset($_SESSION['venda_finalizada'])){$ok=$_SESSION['venda_finalizada'];cabecalho('Compra finalizada');echo '<div class="painel"><h1>Compra registrada!</h1><p>Pedido nº '.(int)$ok['id'].' foi salvo no banco de dados.</p><h2>Total: '.dinheiro($ok['total']).'</h2><a class="btn btn-primario" href="produtos.php">Voltar aos produtos</a></div>';rodape();exit;}
$d=$_SESSION['dados_compra']??['nome'=>usuario()['nome'],'email'=>usuario()['email'],'telefone'=>'','cep'=>'','endereco'=>'','numero'=>'','complemento'=>'','cidade'=>'','estado'=>''];
cabecalho('Finalizar compra');
?>
<div class="cabecalho"><div><h1><?=($etapa==='dados'?'1. Dados pessoais e endereço':'2. Pagamento e recebimento')?></h1><p class="sub">Subtotal dos produtos: <?=dinheiro($subtotal)?></p></div></div>
<?php if($erro):?><div class="aviso aviso-erro"><?=h($erro)?></div><?php endif;?>
<?php if($etapa==='dados'):?><div class="painel formulario"><form method="post"><input type="hidden" name="acao" value="dados"><div class="campo"><label>Nome completo *</label><input name="nome" required value="<?=h($d['nome'])?>"></div><div class="duas-colunas"><div class="campo"><label>E-mail *</label><input type="email" name="email" required value="<?=h($d['email'])?>"></div><div class="campo"><label>Telefone *</label><input name="telefone" required value="<?=h($d['telefone'])?>"></div></div><div class="duas-colunas"><div class="campo"><label>CEP *</label><input name="cep" required value="<?=h($d['cep'])?>"></div><div class="campo"><label>Estado *</label><input name="estado" required value="<?=h($d['estado'])?>"></div></div><div class="campo"><label>Endereço *</label><input name="endereco" required value="<?=h($d['endereco'])?>"></div><div class="duas-colunas"><div class="campo"><label>Número *</label><input name="numero" required value="<?=h($d['numero'])?>"></div><div class="campo"><label>Complemento</label><input name="complemento" value="<?=h($d['complemento'])?>"></div></div><div class="campo"><label>Cidade *</label><input name="cidade" required value="<?=h($d['cidade'])?>"></div><div class="acoes"><a class="btn btn-claro" href="carrinho.php">Voltar ao carrinho</a><button class="btn btn-primario">Continuar</button></div></form></div>
<?php else:?><div class="painel formulario"><form method="post"><input type="hidden" name="acao" value="finalizar"><div class="campo"><label>Forma de pagamento</label><select name="pagamento" required><option value="">Selecione</option><option value="pix">PIX</option><option value="credito">Cartão de crédito</option><option value="debito">Cartão de débito</option><option value="dinheiro">Dinheiro</option></select></div><div class="campo"><label>Como deseja receber?</label><select name="entrega" id="entrega" required><option value="">Selecione</option><option value="retirada">Retirar na loja (grátis)</option><option value="entrega">Entrega (frete estimado R$ 10,00)</option></select></div><div class="linha-total"><strong>Subtotal: <?=dinheiro($subtotal)?></strong><p>Frete: calculado conforme a opção de recebimento (R$ 0,00 ou R$ 10,00).</p></div><div class="acoes"><a class="btn btn-claro" href="compra.php?etapa=dados">Voltar aos dados</a><button class="btn btn-primario">Confirmar compra</button></div></form></div><?php endif;?>
<?php rodape(); ?>
