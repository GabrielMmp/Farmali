
<?php

ini_set('display_errors', '1');
error_reporting(E_ALL);

$servidor = 'sql209.infinityfree.com';
$porta = 3306;
$banco = 'if0_43525538_db_farmali';
$usuario = 'if0_43525538';
$senha = 'farmali1122';

try {
    $conexao = new PDO(
        "mysql:host=$servidor;port=$porta;dbname=$banco;charset=utf8mb4",
        $usuario,
        $senha,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false
        ]
    );

} catch (PDOException $e) {
    die("Erro de conexão: " . $e->getMessage());
}
