const seedProducts = [
 {id:1,code:"35846",name:"A CADASTRAR",category:"Diversos",cost:.01,margin:0,price:.01,supplier:"MERCK BRASIL",minimum:4,stock:4},
 {id:2,code:"24171",name:"ADOÇANTE CAMPO MASC. HIDRAT. CHOCOL.",category:"Perfumaria",cost:7.58,margin:100,price:11.99,supplier:"PERFUMARIA",minimum:0,stock:3},
 {id:3,code:"32897",name:"ANTISSÉPTICO BUCAL P.SAUDE 250ML",category:"Higiene",cost:7.16,margin:100,price:10.99,supplier:"PERFUMARIA",minimum:1,stock:0},
 {id:4,code:"50880",name:"APARELHO DE BARBA COM 2 LÂMINAS",category:"Higiene",cost:4.59,margin:45,price:6.66,supplier:"PERFUMARIA",minimum:0,stock:2},
 {id:5,code:"28054",name:"AAS 100MG C/30CP SANOFI",category:"Medicamentos",cost:18.17,margin:33.24,price:24.21,supplier:"SANOFI",minimum:1,stock:0},
 {id:6,code:"6570",name:"ABACATEIRO 30ML",category:"Fitoterápicos",cost:3.53,margin:46.22,price:5.16,supplier:"REGIUS",minimum:1,stock:0},
 {id:7,code:"39652",name:"ABC CREME 20 GRAMAS HERTZ",category:"Cuidados",cost:16.52,margin:29.06,price:21.32,supplier:"HERTZ",minimum:3,stock:0},
 {id:8,code:"6277",name:"ABC SOLUÇÃO 50ML",category:"Cuidados",cost:15.42,margin:46.34,price:22.56,supplier:"HERTZ",minimum:1,stock:0}
];
const roles={admin:"Administrador",manager:"Gerente",operator:"Operador",viewer:"Consulta"};
let products=JSON.parse(localStorage.getItem("farmali_products")||"null")||seedProducts;
let users=JSON.parse(localStorage.getItem("farmali_users")||"null")||[
 {name:"Administrador do sistema",login:"admin",role:"admin"},
 {name:"Operador de loja",login:"operador",role:"operator"},
 {name:"Consulta",login:"consulta",role:"viewer"}
];
let movements=JSON.parse(localStorage.getItem("farmali_moves")||"[]");
let currentUser=JSON.parse(sessionStorage.getItem("farmali_user")||"null")||users[0];
const $=id=>document.getElementById(id);
const money=n=>Number(n||0).toLocaleString("pt-BR",{style:"currency",currency:"BRL"});
const canEdit=()=>["admin","manager"].includes(currentUser.role);
const canMove=()=>["admin","manager","operator"].includes(currentUser.role);
function persist(){localStorage.setItem("farmali_products",JSON.stringify(products));localStorage.setItem("farmali_users",JSON.stringify(users));localStorage.setItem("farmali_moves",JSON.stringify(movements))}
function toast(msg){$("toast").textContent=msg;$("toast").classList.add("show");setTimeout(()=>$("toast").classList.remove("show"),2400)}
function go(page){
 if(page==="usuarios"&&currentUser.role!=="admin"){toast("Apenas administradores podem gerenciar usuários.");return}
 if(page==="cadastro"&&currentUser.role==="viewer"){toast("Seu perfil permite apenas consultas.");return}
 document.querySelectorAll(".page").forEach(p=>p.hidden=true);
 const target=$("page-"+page);
 if(target){target.hidden=false}else{$("page-placeholder").hidden=false;$("placeholderTitle").textContent=({pagar:"Contas a pagar",receber:"Contas a receber",custos:"Custos",ajuda:"Central de ajuda",manutencao:"Manutenção",nota:"Nota eletrônica",convenio:"Convênios",sap:"Integração SAP",fornecedores:"Fornecedores",categorias:"Categorias"}[page]||"Módulo");}
 document.querySelectorAll(".menu-item").forEach(b=>b.classList.toggle("active",b.dataset.page===page||(page==="usuarios"&&b.dataset.page==="cadastro")));
 if(page==="pesquisa")renderProducts();if(page==="usuarios")renderUsers();if(page==="movimentacao")renderMovements();if(page==="inicio")renderDashboard();if(page==="relatorios")renderReports();
}
document.querySelectorAll("[data-page]").forEach(b=>b.addEventListener("click",()=>go(b.dataset.page)));
document.addEventListener("click",e=>{const b=e.target.closest("[data-go]");if(b)go(b.dataset.go)});
$("logout").addEventListener("click",()=>{const next=prompt("Digite o login para alternar usuário:\n"+users.map(u=>u.login+" ("+roles[u.role]+")").join("\n"),"admin");if(!next)return;const found=users.find(u=>u.login.toLowerCase()===next.trim().toLowerCase());if(!found){toast("Usuário não encontrado.");return}currentUser=found;sessionStorage.setItem("farmali_user",JSON.stringify(currentUser));updateUser();go("inicio");toast("Acesso alterado para "+roles[found.role]+".")});
function updateUser(){$("statusUser").textContent=currentUser.login.toUpperCase();document.querySelectorAll('[data-page="cadastro"],[data-page="movimentacao"],[data-page="relatorios"],[data-page="pagar"],[data-page="receber"],[data-page="custos"],[data-page="manutencao"],[data-page="nota"],[data-page="convenio"],[data-page="sap"]').forEach(b=>b.style.opacity=(currentUser.role==="viewer"&&b.dataset.page!=="relatorios")?".55":"1");$("newProduct").style.display=canEdit()?"":"none";$("permissionNote").textContent=canEdit()?"Edição liberada para "+roles[currentUser.role]:"Perfil somente para consulta"}
function renderDashboard(){const total=products.reduce((s,p)=>s+Number(p.stock),0),low=products.filter(p=>p.stock<=p.minimum);$("totalProducts").textContent=products.length.toLocaleString("pt-BR");$("totalStock").textContent=total.toLocaleString("pt-BR");$("lowStock").textContent=low.length;$("stockValue").textContent=money(products.reduce((s,p)=>s+Number(p.cost)*Number(p.stock),0));$("lowStockList").innerHTML=low.slice(0,5).map(p=>`<div class="low-row"><div><b>${esc(p.name)}</b><small>Cód. ${esc(p.code)} · Mínimo: ${p.minimum}</small></div><span class="qty-low">${p.stock} un.</span></div>`).join("")||'<div class="empty">Nenhum produto com estoque baixo.</div>'}
function renderProducts(){
 const q=$("search").value.toLowerCase(),sup=$("supplierFilter").value,cat=$("categoryFilter").value,st=$("stockFilter").value;
 const suppliers=[...new Set(products.map(p=>p.supplier).filter(Boolean))].sort(),cats=[...new Set(products.map(p=>p.category).filter(Boolean))].sort();
 const setOptions=(id,arr,label)=>{const el=$(id),old=el.value;el.innerHTML=`<option value="">${label}</option>`+arr.map(x=>`<option>${esc(x)}</option>`).join("");el.value=old};
 setOptions("supplierFilter",suppliers,"Todos os fornecedores");setOptions("categoryFilter",cats,"Todas as categorias");
 const filtered=products.filter(p=>(p.code.toLowerCase().includes(q)||p.name.toLowerCase().includes(q))&&(!sup||p.supplier===sup)&&(!cat||p.category===cat)&&(!st||(st==="low"&&p.stock<=p.minimum&&p.stock>0)||(st==="zero"&&p.stock==0)||(st==="ok"&&p.stock>p.minimum)));
 $("resultCount").textContent=filtered.length+" produtos encontrados";$("tableInfo").textContent="Exibindo "+filtered.length+" de "+products.length+" produtos";
 $("productRows").innerHTML=filtered.map(p=>{const state=p.stock==0?"zero":p.stock<=p.minimum?"low":"ok",label=state==="zero"?"ZERADO":state==="low"?"BAIXO":"NORMAL";return `<tr><td>${esc(p.code)}</td><td><b>${esc(p.name)}</b></td><td>${esc(p.category||"—")}</td><td>${money(p.cost)}</td><td>${Number(p.margin).toFixed(2).replace(".",",")}%</td><td class="price">${money(p.price)}</td><td>${esc(p.supplier||"—")}</td><td>${p.minimum}</td><td><span class="stock-badge ${state}">${p.stock}</span></td><td><span class="status-badge">${label}</span></td><td><div class="row-actions"><button data-view="${p.id}">Ver</button>${canEdit()?`<button data-edit="${p.id}">Editar</button>`:""}</div></td></tr>`}).join("")||'<tr><td colspan="11" class="empty">Nenhum produto corresponde à pesquisa.</td></tr>';
 $("productRows").querySelectorAll("[data-edit]").forEach(b=>b.onclick=()=>openProduct(Number(b.dataset.edit)));$("productRows").querySelectorAll("[data-view]").forEach(b=>b.onclick=()=>viewProduct(Number(b.dataset.view)));
}
function esc(s){return String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
["search","supplierFilter","categoryFilter","stockFilter"].forEach(id=>$(id).addEventListener(id==="search"?"input":"change",renderProducts));
$("clearFilters").onclick=()=>{$("search").value="";$("supplierFilter").value="";$("categoryFilter").value="";$("stockFilter").value="";renderProducts()};
function openProduct(id=null){if(!canEdit()){toast("Seu perfil não permite cadastrar ou alterar produtos.");return}const p=products.find(x=>x.id===id);$("productForm").reset();$("editId").value=p?.id||"";$("dialogTitle").textContent=p?"Alterar produto":"Cadastrar produto";$("pCode").value=p?.code||"";$("pName").value=p?.name||"";$("pCategory").value=p?.category||"";$("pSupplier").value=p?.supplier||"";$("pCost").value=p?.cost??0;$("pMargin").value=p?.margin??30;$("pPrice").value=p?.price??0;$("pMinimum").value=p?.minimum??0;$("pStock").value=p?.stock??0;$("productDialog").showModal()}
function closeProduct(){$("productDialog").close()}
$("newProduct").onclick=()=>openProduct();$("closeDialog").onclick=closeProduct;$("cancelDialog").onclick=closeProduct;
$("pCost").addEventListener("input",()=>{const c=Number($("pCost").value),m=Number($("pMargin").value);$("pPrice").value=(c*(1+m/100)).toFixed(2)});
$("pMargin").addEventListener("input",()=>{const c=Number($("pCost").value),m=Number($("pMargin").value);$("pPrice").value=(c*(1+m/100)).toFixed(2)});
$("productForm").onsubmit=e=>{e.preventDefault();const id=Number($("editId").value),code=$("pCode").value.trim();if(products.some(p=>p.code===code&&p.id!==id)){toast("Já existe um produto com esse código.");return}const item={id:id||Date.now(),code,name:$("pName").value.trim(),category:$("pCategory").value.trim(),supplier:$("pSupplier").value.trim(),cost:Number($("pCost").value),margin:Number($("pMargin").value),price:Number($("pPrice").value),minimum:Number($("pMinimum").value),stock:Number($("pStock").value)};if(id){products=products.map(p=>p.id===id?item:p);toast("Produto alterado com sucesso.")}else{products.unshift(item);toast("Produto cadastrado com sucesso.")}persist();closeProduct();renderProducts();renderDashboard()};
function viewProduct(id){const p=products.find(x=>x.id===id);alert(`PRODUTO ${p.code}\n\n${p.name}\nCategoria: ${p.category}\nFornecedor: ${p.supplier}\nCusto: ${money(p.cost)}\nPreço: ${money(p.price)}\nEstoque: ${p.stock} (mínimo ${p.minimum})`)}
function renderUsers(){$("userRows").innerHTML=users.map(u=>`<tr><td><b>${esc(u.name)}</b></td><td>${esc(u.login)}</td><td>${roles[u.role]}</td><td>${u.role==="admin"?"Acesso completo":u.role==="manager"?"Cadastro e estoque":u.role==="operator"?"Consulta e movimentação":"Somente leitura"}</td><td><span class="stock-badge ok">ATIVO</span></td></tr>`).join("")}
$("addUser").onclick=()=>{if(currentUser.role!=="admin"){toast("Acesso restrito.");return}$("userDialog").showModal()};$("closeUserDialog").onclick=$("cancelUser").onclick=()=>$("userDialog").close();
$("userForm").onsubmit=e=>{e.preventDefault();const login=$("uLogin").value.trim();if(users.some(u=>u.login.toLowerCase()===login.toLowerCase())){toast("Este login já existe.");return}users.push({name:$("uName").value.trim(),login,role:$("uRole").value});persist();$("userDialog").close();$("userForm").reset();renderUsers();toast("Usuário criado.")};
function renderMovements(){$("moveProduct").innerHTML=products.map(p=>`<option value="${p.id}">${esc(p.code)} — ${esc(p.name)} (Estoque: ${p.stock})</option>`).join("");$("saveMovement").disabled=!canMove();$("movementList").innerHTML=movements.slice(0,12).map(m=>`<div class="movement-item"><div><b>${esc(m.name)}</b><small>${esc(m.date)} · ${esc(m.user)}</small></div><span class="${m.type==="in"?"movement-in":"movement-out"}">${m.type==="in"?"+":"−"}${m.qty} un.</span></div>`).join("")||'<div class="empty">Nenhuma movimentação registrada.</div>'}
$("saveMovement").onclick=()=>{if(!canMove()){toast("Seu perfil não permite movimentações.");return}const p=products.find(x=>x.id===Number($("moveProduct").value)),qty=Number($("moveQty").value),type=$("moveType").value;if(!p||qty<1){toast("Informe um produto e uma quantidade válida.");return}if(type==="out"&&p.stock<qty){toast("Estoque insuficiente para essa saída.");return}p.stock+=type==="in"?qty:-qty;movements.unshift({name:p.name,qty,type,date:new Date().toLocaleString("pt-BR"),user:currentUser.login});persist();renderMovements();renderDashboard();toast("Movimentação registrada.")};
function renderReports(){const total=products.length,low=products.filter(p=>p.stock<=p.minimum).length,zero=products.filter(p=>p.stock==0).length; $("reportContent").innerHTML=`<div class="stats"><article class="stat-card"><div><small>TOTAL DE ITENS</small><strong>${total}</strong></div></article><article class="stat-card"><div><small>ESTOQUE BAIXO</small><strong>${low}</strong></div></article><article class="stat-card"><div><small>SEM ESTOQUE</small><strong>${zero}</strong></div></article><article class="stat-card"><div><small>VALOR EM ESTOQUE</small><strong>${money(products.reduce((s,p)=>s+p.cost*p.stock,0))}</strong></div></article></div>`}
function tick(){const d=new Date();$("clock").textContent=d.toLocaleDateString("pt-BR")+" · "+d.toLocaleTimeString("pt-BR");$("statusDate").textContent=d.toLocaleDateString("pt-BR");$("statusTime").textContent=d.toLocaleTimeString("pt-BR");$("today").textContent=d.toLocaleDateString("pt-BR",{weekday:"long",day:"2-digit",month:"long",year:"numeric"})}
updateUser();tick();setInterval(tick,1000);renderDashboard();