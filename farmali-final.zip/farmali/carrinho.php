<?php
require_once __DIR__.'/includes.php'; exigir_perfil(['cliente','funcionario','admin']);
$uid=usuario()['id'];
if($_SERVER['REQUEST_METHOD']==='POST'){
 $acao=$_POST['acao']??'';$id=(int)($_POST['id']??0);
 if($acao==='adicionar'){$q=max(1,(int)($_POST['quantidade']??1));$s=$conexao->prepare("SELECT QUANTIDADE_ESTOQUE FROM PRODUTO WHERE COD_PRODUTO=? AND STATUS='ATIVO'");$s->execute([$id]);$estoque=$s->fetchColumn();if($estoque===false||$q>(int)$estoque){$_SESSION['mensagem']='Produto indisponível ou quantidade maior que o estoque.';}else{$s=$conexao->prepare('INSERT INTO CARRINHO(ID_USUARIO,COD_PRODUTO,QUANTIDADE) VALUES(?,?,?) ON DUPLICATE KEY UPDATE QUANTIDADE=QUANTIDADE+VALUES(QUANTIDADE)');$s->execute([$uid,$id,$q]);$s=$conexao->prepare('SELECT QUANTIDADE FROM CARRINHO WHERE ID_USUARIO=? AND COD_PRODUTO=?');$s->execute([$uid,$id]);$atual=(int)$s->fetchColumn();if($atual>(int)$estoque){$s=$conexao->prepare('UPDATE CARRINHO SET QUANTIDADE=? WHERE ID_USUARIO=? AND COD_PRODUTO=?');$s->execute([(int)$estoque,$uid,$id]);} }
 }
 if($acao==='atualizar'){$q=max(1,(int)($_POST['quantidade']??1));$s=$conexao->prepare('SELECT QUANTIDADE_ESTOQUE FROM PRODUTO WHERE COD_PRODUTO=?');$s->execute([$id]);$est=(int)$s->fetchColumn();$s=$conexao->prepare('UPDATE CARRINHO SET QUANTIDADE=? WHERE ID_USUARIO=? AND COD_PRODUTO=?');$s->execute([min($q,$est),$uid,$id]);}
 if($acao==='remover'){$s=$conexao->prepare('DELETE FROM CARRINHO WHERE ID_USUARIO=? AND COD_PRODUTO=?');$s->execute([$uid,$id]);}
 if($acao==='limpar'){$s=$conexao->prepare('DELETE FROM CARRINHO WHERE ID_USUARIO=?');$s->execute([$uid]);}
 header('Location: carrinho.php');exit;
}
$s=$conexao->prepare('SELECT p.COD_PRODUTO,p.NOME,p.PRECO,p.QUANTIDADE_ESTOQUE,c.QUANTIDADE FROM CARRINHO c JOIN PRODUTO p ON p.COD_PRODUTO=c.COD_PRODUTO WHERE c.ID_USUARIO=?');$s->execute([$uid]);$itens=$s->fetchAll();$total=0;foreach($itens as $i)$total+=(float)$i['PRECO']*(int)$i['QUANTIDADE'];
cabecalho('Meu carrinho');
?>
<div class="cabecalho"><div><h1>Meu carrinho</h1><p class="sub">Os itens ficam salvos no banco de dados da sua conta.</p></div></div>
<?php if(!$itens):?><div class="painel vazio"><h2>Seu carrinho está vazio</h2><a class="btn btn-primario" href="produtos.php">Continuar comprando</a></div><?php else:?>
<div class="painel"><div class="tabela-area"><table><thead><tr><th>Produto</th><th>Preço</th><th>Quantidade</th><th>Subtotal</th><th></th></tr></thead><tbody><?php foreach($itens as $i):?><tr><td><?=h($i['NOME'])?></td><td><?=dinheiro($i['PRECO'])?></td><td><form class="acoes" method="post"><input type="hidden" name="acao" value="atualizar"><input type="hidden" name="id" value="<?=$i['COD_PRODUTO']?>"><input style="width:80px" type="number" name="quantidade" min="1" max="<?=$i['QUANTIDADE_ESTOQUE']?>" value="<?=$i['QUANTIDADE']?>"><button class="btn btn-claro btn-pequeno">Atualizar</button></form></td><td><?=dinheiro($i['PRECO']*$i['QUANTIDADE'])?></td><td><form method="post"><input type="hidden" name="acao" value="remover"><input type="hidden" name="id" value="<?=$i['COD_PRODUTO']?>"><button class="btn btn-perigo btn-pequeno">Remover</button></form></td></tr><?php endforeach;?></tbody></table></div><div class="linha-total"><strong>Total: <?=dinheiro($total)?></strong></div><div class="acoes"><a class="btn btn-claro" href="produtos.php">Continuar comprando</a><a class="btn btn-primario" href="compra.php?etapa=dados">Finalizar compra</a><form method="post"><input type="hidden" name="acao" value="limpar"><button class="btn btn-perigo">Limpar carrinho</button></form></div></div><?php endif;?>
<?php rodape(); ?>
