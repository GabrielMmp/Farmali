<?php
require_once __DIR__.'/includes.php'; exigir_login();
$perfil=usuario()['perfil']; $busca=trim($_GET['q']??'');
$sql="SELECT p.COD_PRODUTO,p.NOME,p.DESCRICAO,p.PRECO,p.QUANTIDADE_ESTOQUE,c.NOME AS CATEGORIA FROM PRODUTO p LEFT JOIN CATEGORIA c ON c.COD_CATEGORIA=p.COD_CATEGORIA_FK WHERE p.STATUS='ATIVO'";
$params=[]; if($busca!==''){ $sql.=' AND (p.NOME LIKE ? OR p.DESCRICAO LIKE ?)'; $params=['%'.$busca.'%','%'.$busca.'%']; } $sql.=' ORDER BY p.NOME'; $s=$conexao->prepare($sql);$s->execute($params);$produtos=$s->fetchAll();
$msg=$_SESSION['mensagem']??'';unset($_SESSION['mensagem']);
cabecalho('Produtos');
?>
<div class="cabecalho"><div><h1>Produtos</h1><p class="sub"><?php if($perfil==='cliente'):?>Consulte os produtos e seus preços.<?php elseif($perfil==='funcionario'):?>Consulte o estoque e registre vendas.<?php else:?>Gerencie o catálogo e consulte os produtos.<?php endif;?></p></div><?php if($perfil==='admin'):?><a class="btn btn-primario" href="crud.php">+ Novo produto</a><?php endif;?></div>
<?php if($msg):?><div class="aviso aviso-ok"><?=h($msg)?></div><?php endif;?>
<form class="filtros" method="get"><input type="search" name="q" placeholder="Buscar produto..." value="<?=h($busca)?>"><button class="btn btn-primario">Buscar</button></form>
<div class="grade"><?php foreach($produtos as $p):?><article class="cartao"><div class="cartao-info"><?php if($perfil!=='cliente'):?><span class="etiqueta"><?=h($p['CATEGORIA']??'Geral')?></span><?php endif;?><h3><?=h($p['NOME'])?></h3><div class="cartao-preco"><strong><?=dinheiro($p['PRECO'])?></strong><?php if($perfil!=='cliente'):?><small>Estoque: <?= (int)$p['QUANTIDADE_ESTOQUE']?></small><?php endif;?></div>
<?php if($perfil==='admin'):?><p class="descricao"><?=h($p['DESCRICAO'])?></p><div class="acoes"><a class="btn btn-claro btn-pequeno" href="crud.php?id=<?=(int)$p['COD_PRODUTO']?>">Editar</a><form method="post" action="crud.php" onsubmit="return confirm('Excluir este produto?')"><input type="hidden" name="acao" value="excluir"><input type="hidden" name="id" value="<?=(int)$p['COD_PRODUTO']?>"><button class="btn btn-perigo btn-pequeno">Excluir</button></form></div><?php endif;?>
<form method="post" action="carrinho.php"><input type="hidden" name="acao" value="adicionar"><input type="hidden" name="id" value="<?=(int)$p['COD_PRODUTO']?>"><label>Quantidade <input style="width:80px" type="number" name="quantidade" min="1" max="<?=($perfil==='cliente'?99:max(1,(int)$p['QUANTIDADE_ESTOQUE']))?>" value="1" required></label><button class="btn btn-primario" type="submit">Adicionar ao carrinho</button></form></div></article><?php endforeach;?><?php if(!$produtos):?><p class="vazio">Nenhum produto encontrado.</p><?php endif;?></div>
<p><a class="btn btn-claro" href="carrinho.php">Abrir carrinho</a></p>
<?php rodape(); ?>
