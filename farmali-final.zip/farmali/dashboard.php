<?php
require_once __DIR__.'/includes.php'; exigir_login();
if (usuario()['perfil']==='cliente') { header('Location: produtos.php'); exit; }
if (usuario()['perfil']==='admin') {
 $qtd=(int)$conexao->query("SELECT COUNT(*) FROM PRODUTO WHERE STATUS='ATIVO'")->fetchColumn();
 $usuarios=(int)$conexao->query("SELECT COUNT(*) FROM USUARIO WHERE ATIVO=1")->fetchColumn();
 $vendas=(int)$conexao->query("SELECT COUNT(*) FROM VENDA")->fetchColumn();
} else { $qtd=(int)$conexao->query("SELECT COUNT(*) FROM PRODUTO WHERE STATUS='ATIVO'")->fetchColumn(); $usuarios=0; $vendas=0; }
cabecalho('Painel Farmali');
?>
<div class="cabecalho"><div><h1>Olá, <?=h(usuario()['nome'])?>!</h1><p class="sub">Acesso de <?=h(usuario()['perfil'])?>.</p></div><a class="btn btn-primario" href="produtos.php">Abrir produtos</a></div>
<div class="stats"><div class="stat"><span>Produtos ativos</span><strong><?=$qtd?></strong></div><?php if(usuario()['perfil']==='admin'):?><div class="stat"><span>Usuários ativos</span><strong><?=$usuarios?></strong></div><div class="stat"><span>Vendas registradas</span><strong><?=$vendas?></strong></div><?php endif;?></div>
<div class="painel"><h2>O que você pode fazer</h2><div class="acoes"><a class="btn btn-primario" href="produtos.php">Ver produtos</a><?php if(usuario()['perfil']==='admin'):?><a class="btn btn-claro" href="crud.php">Cadastrar produto</a><a class="btn btn-claro" href="promover.php">Gerenciar cargos</a><?php endif;?></div></div>
<?php rodape(); ?>
