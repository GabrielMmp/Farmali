<?php
require_once __DIR__.'/includes.php';
session_destroy(); header('Location: login.php'); exit;
