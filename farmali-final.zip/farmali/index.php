<?php
require_once __DIR__.'/includes.php';
header('Location: '.(usuario() ? 'dashboard.php' : 'login.php'));
exit;
