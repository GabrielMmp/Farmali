
<?php
require_once __DIR__.'/includes.php';

if (usuario()) {
    header('Location: dashboard.php');
    exit;
}

$erro = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $acao = $_POST['acao'] ?? 'login';
    $email = trim($_POST['email'] ?? '');
    $senha = $_POST['senha'] ?? '';

    if ($acao === 'cadastro') {

        $nome = trim($_POST['nome'] ?? '');

        if ($nome === '' || !filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($senha) < 6) {

            $erro = 'Preencha nome, e-mail válido e senha com pelo menos 6 caracteres.';

        } else {

            try {

                $s = $conexao->prepare(
                    "INSERT INTO USUARIO(NOME, EMAIL, SENHA, PERFIL)
                    VALUES (?, ?, ?, 'cliente')"
                );

                $s->execute([
                    $nome,
                    $email,
                    password_hash($senha, PASSWORD_DEFAULT)
                ]);

                $_SESSION['usuario'] = [
                    'id' => (int)$conexao->lastInsertId(),
                    'nome' => $nome,
                    'email' => $email,
                    'perfil' => 'cliente'
                ];

                header('Location: compra.php?etapa=dados');
                exit;

            } catch (PDOException $e) {

                $erro = 'Não foi possível realizar o cadastro.';

            }
        }

    } else {

        $s = $conexao->prepare(
            'SELECT ID_USUARIO, NOME, EMAIL, SENHA, PERFIL, ATIVO
             FROM USUARIO WHERE EMAIL = ?'
        );

        $s->execute([$email]);
        $u = $s->fetch();

        if ($u && (int)$u['ATIVO'] === 1 && password_verify($senha, $u['SENHA'])) {

            $_SESSION['usuario'] = [
                'id' => (int)$u['ID_USUARIO'],
                'nome' => $u['NOME'],
                'email' => $u['EMAIL'],
                'perfil' => $u['PERFIL']
            ];

            header('Location: dashboard.php');
            exit;
        }

        $erro = 'E-mail ou senha incorretos, ou conta inativa.';
    }
}
?>

<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Entrar | Farmali</title>

    <link rel="stylesheet" href="assets/css/estilo.css">
</head>

<body>

    <div class="pagina-login">

        <div class="container-acesso">

            <div class="cabecalho-acesso">

                <img class="login-logo"
                     src="assets/img/logo.png"
                     alt="Farmali">

                <h1>Bem-vindo à Farmali</h1>

                <p class="sub">Entre ou crie sua conta</p>

            </div>

            <?php if ($erro): ?>

                <div class="aviso aviso-erro">
                    <?= h($erro) ?>
                </div>

            <?php endif; ?>

            <div class="formularios-acesso">

                <!-- LOGIN -->

                <div class="caixa-login">

                    <h2>Login</h2>

                    <form method="post">

                        <input type="hidden" name="acao" value="login">

                        <div class="campo">
                            <label>E-mail</label>
                            <input type="email" name="email" required>
                        </div>

                        <div class="campo">
                            <label>Senha</label>
                            <input type="password" name="senha" required>
                        </div>

                        <button class="btn btn-primario" type="submit">
                            Entrar
                        </button>

                    </form>

                </div>

                <!-- CADASTRO -->

                <div class="caixa-login">

                    <h2>Cadastrar cliente</h2>

                    <form method="post">

                        <input type="hidden" name="acao" value="cadastro">

                        <div class="campo">
                            <label>Nome completo</label>
                            <input type="text" name="nome" required>
                        </div>

                        <div class="campo">
                            <label>E-mail</label>
                            <input type="email" name="email" required>
                        </div>

                        <div class="campo">
                            <label>Senha (mínimo 6 caracteres)</label>
                            <input type="password" name="senha" minlength="6" required>
                        </div>

                        <button class="btn btn-primario" type="submit">
                            Criar conta
                        </button>

                    </form>

                    <p class="dica">
                        Novos cadastros entram como cliente.
                        O administrador pode alterar o perfil depois.
                    </p>

                </div>

            </div>

        </div>

    </div>

</body>

</html>
