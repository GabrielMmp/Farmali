# Farmali ERP — protótipo de gestão comercial

## Como executar
1. Extraia o ZIP.
2. Abra a pasta `farmali_erp`.
3. Abra `index.html` no navegador (Chrome, Edge ou Firefox).

Não precisa instalar dependências nem configurar servidor para testar o protótipo.

## Funcionalidades implementadas
- Menu superior inspirado no sistema de referência.
- Painel inicial com indicadores de produtos e estoque.
- Pesquisa por código ou descrição.
- Filtros por fornecedor, categoria e situação do estoque.
- Cadastro e edição de produtos, com validação de código duplicado.
- Cálculo automático do preço a partir do custo e da margem.
- Movimentações de entrada e saída com validação de saldo.
- Indicadores e lista de produtos com estoque baixo.
- Usuários demonstrativos com quatro perfis.
- Persistência local no navegador via localStorage.

## Usuários de demonstração
- `admin` — Administrador
- `operador` — Operador
- `consulta` — Consulta

Use o botão **Sair** no menu para alternar o login. O protótipo não usa senhas.

## Importante sobre produção
Este projeto é um protótipo front-end. Os dados ficam armazenados apenas no navegador e não são compartilhados entre computadores. As permissões são demonstrativas e podem ser contornadas por quem manipular o navegador. Para uso real, será necessário integrar backend, banco de dados, login com senha, controle de acesso no servidor, backups e trilha de auditoria.
