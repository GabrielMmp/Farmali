# Farmali — sistema integrado

Projeto PHP + MySQL/MariaDB para executar localmente no WAMP.

## O que foi integrado
- Login e cadastro na mesma página (`login.php`). Todo cadastro novo recebe perfil **cliente**.
- Perfis: **admin** (acesso administrativo e CRUD), **funcionario** (consulta estoque e registra vendas) e **cliente** (vitrine com nome/preço e compra online).
- Produtos consultados no banco; criação, edição e exclusão lógica gravadas diretamente no banco.
- Carrinho persistente por usuário na tabela `CARRINHO`.
- Compra online em duas etapas: dados pessoais/endereço e depois pagamento/recebimento.
- Pagamento: PIX, crédito, débito e dinheiro. Recebimento: retirada grátis ou entrega com frete estimado fixo de R$ 10,00.
- Ao confirmar a venda, grava pedido e itens, atualiza estoque e limpa o carrinho dentro de uma transação.
- Administrador pode buscar usuários por nome e e-mail e alterar seu perfil em `promover.php`.

## Instalação
1. Copie a pasta `Farmali` para `C:\wamp64\www\Farmali` (ou para a pasta `www` do seu WAMP).
2. Ligue Apache e MySQL/MariaDB.
3. Abra phpMyAdmin e importe `database/farmali.sql`.
4. Confira `config/conexao.php`. O projeto está configurado para porta **3307**, usuário `root` e senha vazia, conforme a configuração que estava no projeto atualizado. Se seu MySQL usar 3306, altere `$porta` para `3306`.
5. Acesse `http://localhost/Farmali/`.

## Primeiro acesso de administrador
- E-mail: `admin@farmali.com`
- Senha: `Farmali@123`

Altere a senha após o primeiro acesso (a edição de senha pode ser adicionada como próxima melhoria). Não publique esse acesso em um servidor real.

## Páginas principais
- `login.php`: login e cadastro de cliente.
- `dashboard.php`: painel administrativo/funcionário.
- `produtos.php`: listagem para todos os perfis; cliente vê apenas nome e preço.
- `crud.php`: cadastro, edição e exclusão de produtos (admin).
- `carrinho.php`: carrinho do cliente/funcionário, salvo no banco.
- `compra.php`: dados pessoais e finalização da compra/venda.
- `promover.php`: busca de usuário e alteração de cargo (admin).

## Observações didáticas
O frete foi implementado como valor fixo estimado de R$ 10,00 para manter a regra simples e fácil de entender. Para cálculo real por CEP, será necessário integrar uma API de frete ou definir uma tabela de regiões. O pagamento é registrado como opção escolhida; não há integração com gateway, PIX real ou maquininha.
