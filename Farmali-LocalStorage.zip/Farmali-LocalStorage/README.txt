# FARMALI — versão LocalStorage

## Como executar
1. Extraia a pasta `Farmali-LocalStorage` para o computador.
2. Abra `login.html` com dois cliques no navegador.
3. Entre com os dados demonstrativos abaixo.

**E-mail:** admin@farmali.com  
**Senha:** 123456

## Funcionalidades
- Painel de gestão com indicadores de estoque.
- Catálogo de produtos com imagens locais.
- Pesquisa por nome, descrição e categoria.
- Filtro por categoria e ordenação.
- CRUD de produtos: cadastrar, editar e excluir.
- Persistência dos produtos com `localStorage`.
- Administração para restaurar os dados iniciais.

## Observações
- Esta versão funciona sem WAMP, PHP, MySQL ou internet.
- Os dados ficam armazenados somente no navegador e no perfil de usuário atual.
- Limpar os dados do navegador pode apagar as alterações.
- O login é apenas demonstrativo e não oferece segurança real.
- O campo imagem aceita o nome de um arquivo que esteja na pasta `img`.
- A versão PHP + MySQL deverá ser usada para publicação em servidor WAMP64.

## Organização
- `login.html`: tela de entrada.
- `index.html`: painel principal.
- `produtos.html`: pesquisa, filtros e CRUD.
- `admin.html`: área administrativa.
- `app.js`: regras simples e armazenamento local.
- `app.css`: estilo visual comum às páginas.
- `img/`: imagens individuais dos produtos.
