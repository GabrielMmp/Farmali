
/* Dados iniciais para a primeira execução */
const PRODUTOS_INICIAIS = [{ "id": 1, "name": "Dipirona 500mg", "category": "Medicamentos", "price": 8.9, "stock": 45, "description": "Analgésico e antitérmico. Embalagem com 10 comprimidos.", "image": "dipirona.svg" }, { "id": 2, "name": "Paracetamol 750mg", "category": "Medicamentos", "price": 12.5, "stock": 32, "description": "Analgésico e antitérmico. Embalagem com 20 comprimidos.", "image": "paracetamol.svg" }, { "id": 3, "name": "Vitamina C 1g", "category": "Vitaminas", "price": 19.9, "stock": 18, "description": "Suplemento de vitamina C em comprimidos efervescentes.", "image": "vitamina-c.svg" }, { "id": 4, "name": "Shampoo Neutro", "category": "Higiene", "price": 16.9, "stock": 24, "description": "Shampoo para uso diário, frasco de 350ml.", "image": "shampoo.svg" }, { "id": 5, "name": "Sabonete Líquido", "category": "Higiene", "price": 11.9, "stock": 40, "description": "Sabonete líquido para mãos e corpo, 250ml.", "image": "sabonete.svg" }, { "id": 6, "name": "Protetor Solar FPS 50", "category": "Beleza", "price": 42.9, "stock": 12, "description": "Protetor solar facial e corporal, 120ml.", "image": "protetor.svg" }, { "id": 7, "name": "Álcool 70%", "category": "Higiene", "price": 7.5, "stock": 28, "description": "Álcool 70% para higienização, frasco de 500ml.", "image": "alcool.svg" }, { "id": 8, "name": "Curativo Adesivo", "category": "Cuidados", "price": 6.9, "stock": 60, "description": "Curativos adesivos sortidos, caixa com 10 unidades.", "image": "curativo.svg" }, { "id": 9, "name": "Creme Hidratante", "category": "Beleza", "price": 24.9, "stock": 15, "description": "Creme hidratante corporal, 200g.", "image": "creme.svg" }, { "id": 10, "name": "Soro Fisiológico 0,9%", "category": "Cuidados", "price": 5.9, "stock": 50, "description": "Solução fisiológica, frasco de 100ml.", "image": "soro.svg" }];
const CHAVE_PRODUTOS = "farmali_produtos";
const CHAVE_USUARIO = "farmali_usuario";

/* Lê os produtos salvos ou inicia com a lista demonstrativa */
function obterProdutos() {
  let dados = localStorage.getItem(CHAVE_PRODUTOS);
  if (!dados) { localStorage.setItem(CHAVE_PRODUTOS, JSON.stringify(PRODUTOS_INICIAIS)); return [...PRODUTOS_INICIAIS]; }
  try { return JSON.parse(dados); } catch (e) { return [...PRODUTOS_INICIAIS]; }
}
/* Salva a lista atual no navegador */
function salvarProdutos(lista) { localStorage.setItem(CHAVE_PRODUTOS, JSON.stringify(lista)); }
/* Formata valores como moeda brasileira */
function moeda(valor) { return Number(valor).toLocaleString("pt-BR", { style: "currency", currency: "BRL" }); }
/* Exibe uma mensagem curta de confirmação */
function aviso(msg) { const el = document.getElementById("toast"); if (el) { el.textContent = msg; el.classList.add("show"); setTimeout(() => el.classList.remove("show"), 2600); } }
/* Protege páginas internas: só entra quem fez login */
function exigirLogin() { if (!localStorage.getItem(CHAVE_USUARIO)) { location.href = "login.html"; } }
/* Encerra a sessão demonstrativa */
function sair() { localStorage.removeItem(CHAVE_USUARIO); location.href = "login.html"; }
/* Faz login local de demonstração */
function fazerLogin(event) {
  event.preventDefault();
  const email = document.getElementById("email").value.trim();
  const senha = document.getElementById("senha").value;
  if (email === "admin@farmali.com" && senha === "123456") {
    localStorage.setItem(CHAVE_USUARIO, JSON.stringify({ nome: "Administrador", email }));
    location.href = "index.html";
  } else { document.getElementById("erro-login").textContent = "E-mail ou senha incorretos."; }
}
/* Atualiza os indicadores do painel */
function carregarPainel() {
  exigirLogin(); const lista = obterProdutos();
  const total = lista.length, unidades = lista.reduce((s, p) => s + Number(p.stock || 0), 0);
  const baixo = lista.filter(p => Number(p.stock) < 10).length;
  const valor = lista.reduce((s, p) => s + Number(p.price) * Number(p.stock), 0);
  document.getElementById("stat-produtos").textContent = total;
  document.getElementById("stat-unidades").textContent = unidades;
  document.getElementById("stat-baixo").textContent = baixo;
  document.getElementById("stat-valor").textContent = moeda(valor);
  const tbody = document.getElementById("recentes");
  tbody.innerHTML = lista.slice(0, 5).map(p => `<tr><td>${escapar(p.name)}</td><td>${escapar(p.category)}</td><td>${moeda(p.price)}</td><td><span class="badge ${p.stock < 10 ? 'low' : ''}">${p.stock} un.</span></td></tr>`).join("");
}
/* Evita que textos cadastrados virem código HTML */
function escapar(texto) { return String(texto ?? "").replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c])); }

/* Monta a tela de produtos e aplica pesquisa e filtros */
function carregarProdutos() {
  exigirLogin(); const busca = document.getElementById("busca"), filtro = document.getElementById("categoria"), ordem = document.getElementById("ordem");
  function desenhar() {
    let lista = obterProdutos(); const termo = busca.value.toLowerCase().trim();
    if (termo) lista = lista.filter(p => (p.name + " " + p.description + " " + p.category).toLowerCase().includes(termo));
    if (filtro.value !== "Todas") lista = lista.filter(p => p.category === filtro.value);
    if (ordem.value === "nome") lista.sort((a, b) => a.name.localeCompare(b.name, "pt-BR"));
    if (ordem.value === "preco-menor") lista.sort((a, b) => a.price - b.price);
    if (ordem.value === "preco-maior") lista.sort((a, b) => b.price - a.price);
    const grid = document.getElementById("product-grid");
    grid.innerHTML = lista.length ? lista.map(p => `
      <article class="product-card">
        <img class="product-image" src="img/${encodeURIComponent(p.image || '')}" alt="${escapar(p.name)}" onerror="this.src='img/fallback.svg'">
        <div class="product-info"><div class="product-category">${escapar(p.category)}</div>
        <h3>${escapar(p.name)}</h3><div class="product-desc">${escapar(p.description)}</div>
        <div class="product-foot"><span class="price">${moeda(p.price)}</span><span class="stock">${p.stock} em estoque</span></div>
        <div class="card-actions"><button class="btn btn-light btn-small" onclick="editarProduto(${p.id})">Editar</button><button class="btn btn-danger btn-small" onclick="excluirProduto(${p.id})">Excluir</button></div></div>
      </article>`).join("") : `<div class="empty">Nenhum produto encontrado. Tente outro termo ou categoria.</div>`;
    document.getElementById("contador").textContent = `${lista.length} produto(s) encontrado(s)`;
  }
  busca.addEventListener("input", desenhar); filtro.addEventListener("change", desenhar); ordem.addEventListener("change", desenhar); desenhar();
}
/* Abre o formulário de cadastro ou edição */
function abrirModal(id = null) {
  const form = document.getElementById("produto-form"); form.reset();
  document.getElementById("produto-id").value = "";
  document.getElementById("modal-titulo").textContent = id ? "Editar produto" : "Novo produto";
  if (id !== null) {
    const p = obterProdutos().find(x => x.id === id); if (!p) return;
    document.getElementById("produto-id").value = p.id; document.getElementById("nome").value = p.name;
    document.getElementById("categoria-form").value = p.category; document.getElementById("preco").value = p.price;
    document.getElementById("estoque").value = p.stock; document.getElementById("descricao").value = p.description;
    document.getElementById("imagem").value = p.image || "";
  }
  document.getElementById("modal").classList.add("open");
}
function fecharModal() { document.getElementById("modal").classList.remove("open"); }
function editarProduto(id) { abrirModal(id); }
/* Salva um produto novo ou atualiza o existente */
function salvarProduto(event) {
  event.preventDefault(); let lista = obterProdutos(); const id = document.getElementById("produto-id").value;
  const nome = document.getElementById("nome").value.trim(); const preco = Number(document.getElementById("preco").value);
  const estoque = Number(document.getElementById("estoque").value);
  if (!nome || preco < 0 || estoque < 0) { aviso("Confira os dados informados."); return; }
  const item = { id: id ? Number(id) : Date.now(), name: nome, category: document.getElementById("categoria-form").value, price: preco, stock: estoque, description: document.getElementById("descricao").value.trim(), image: document.getElementById("imagem").value.trim() || "fallback.svg" };
  if (id) { lista = lista.map(p => p.id === Number(id) ? item : p); aviso("Produto atualizado!"); }
  else { lista.push(item); aviso("Produto cadastrado!"); }
  salvarProdutos(lista); fecharModal(); document.getElementById("busca").dispatchEvent(new Event("input"));
}
/* Exclui um produto depois de confirmar */
function excluirProduto(id) {
  const p = obterProdutos().find(x => x.id === id); if (!p) return;
  if (confirm(`Deseja excluir "${p.name}"?`)) { salvarProdutos(obterProdutos().filter(x => x.id !== id)); document.getElementById("busca").dispatchEvent(new Event("input")); aviso("Produto excluído."); }
}
/* Permite restaurar a lista demonstrativa original */
function restaurarDados() { if (confirm("Isso apaga suas alterações e restaura os produtos iniciais. Continuar?")) { salvarProdutos(PRODUTOS_INICIAIS); location.reload(); } }
